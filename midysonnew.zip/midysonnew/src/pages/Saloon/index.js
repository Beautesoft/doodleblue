export { ListSalons } from 'component/Admin/Salons/ListSalons/index';
export { CreateSalon } from 'component/Admin/Salons/CreateSalon';
export { SalonDetails } from 'component/Admin/Salons/SalonDetails';