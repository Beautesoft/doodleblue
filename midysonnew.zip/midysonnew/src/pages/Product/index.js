export { ListProduct } from 'component/Admin/Product/ListProduct';
export { CreateProduct } from 'component/Admin/Product/CreateProduct';
export { ProductDetails } from 'component/Admin/Product/ProductDetails';