import React, { Component } from 'react';
export class StaffDetails extends Component {
    render() {
        return (
             <>
             </>
        );
    }
}