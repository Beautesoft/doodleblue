export {Details} from './details'
export {CustomerList} from './customerList'
export {ProductSaleHistory} from './productSaleHistory'
export {StaffDetails} from './staffList'