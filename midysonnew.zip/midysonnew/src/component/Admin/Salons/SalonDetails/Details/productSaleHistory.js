import React, { Component } from 'react';
export class ProductSaleHistory extends Component {
    render() {
        return (
             <>
             </>
        );
    }
}