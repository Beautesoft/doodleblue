import React, { Component } from 'react';
import { NormalSelect, NormalTextarea, NormalButton, NormalModal, NormalInput, NormalMultiSelect } from 'component/common';
import Hairwash from '../../../../assets/images/service1.png'
import close from 'assets/images/cancel.png'
import './style.scss';
import { updateForm, getSelectedTreatmentList } from 'redux/actions/appointment';
import { connect } from 'react-redux';
import { bindActionCreators } from "redux";
import SimpleReactValidator from 'simple-react-validator';
import Availability from './Availability';
import { Cart } from './Cart';
import closeIcon from '../../../../assets/images/close.png';
import { getCommonApi, commonCreateApi } from 'redux/actions/common';
import { dateFormat } from 'service/helperFunctions';
import { history } from 'helpers';

export class SelectTreatmentClass extends Component {
    state = {
        treatmentDetail: [],
        formFields: {
            start_time: "",
            end_time: "",
            Item_Codeid: null,
            add_duration: "",
            emp_no: [],
            requesttherapist: true,
            Item_CodeName: ""
        },
        selectedList: [
             {
                start_time: "",
                end_time: "",
                Item_Codeid: null,
                add_duration: "",
                emp_no: [],
                requesttherapist: false
            }
        ],
        outletOption: [],
        staffOption: [],
        roomOption: [],
        list: [],
        isOpenModal: false,
        categoryList: [],
        treatmentList: [],
        siteList: [],
        treatmentField: {
            category: "",
            treatment: "",
        },
        timeDropdown: [],
        duration: []
    }

    componentWillMount() {
        this.validator = new SimpleReactValidator({
            element: message => <span className="error-message text-danger validNo fs14">{message}</span>,
            autoForceUpdate: this,
        });
        let { appointmentDetail, categoryList, staffOption, selectedList, formFields, duration } = this.state;
        // this.props.getSelectedTreatmentList(`?appt_id=${appointmentDetail.id}`).then((res) => {
        //     console.log("namekkuhkjn", res)
        // })
        let { basicApptDetail } = this.props;
        formFields['start_time'] = basicApptDetail ? basicApptDetail.time:"";
        selectedList[0]['start_time'] = basicApptDetail ? basicApptDetail.time:"";
        this.setState({
            formFields,
            selectedList
        })

        this.props.getCommonApi(`itemdept/`).then((key) => {
            let { status, data } = key;
            if (status === 200) {
                for (let value of data) {
                    categoryList.push({ value: value.id, label: value.itm_desc })
                }
                this.setState({ categoryList })
            }
        })
        this.props.getCommonApi(`appointment/Staffs/?Outlet=${basicApptDetail.branchId}&date=${dateFormat(new Date())}`).then((key) => {
            let { status, data } = key;
            if (status === 200) {
                for (let value of data) {
                    staffOption.push({ value: value.id, label: value.emp_name })
                }
                this.setState({ staffOption })
            }
        })
        this.props.getCommonApi(`treatment/Duration/`).then((key) => {
            let { status, data } = key;
            if (status === 200) {
                for (let value of data) {
                    duration.push({ value: value, label: value })
                }
                this.setState({ duration })
            }
        })
        this.getStaffAvailability();
    }

    getStaffAvailability = () => {
        this.props.getCommonApi(`staffsavailable/?Appt_date=${dateFormat(new Date(), "yyyy-mm-dd")}`).then((key) => {
            let { status, data } = key;
            if (status === 200) {
                // for (let value of data) {
                //     staffList.push({ value: value.id, label: value.emp_name })
                // }
                this.setState({ list:data })
            }
        })
    }

    handleChangeTreatment = async ({ target: { value, name } }) => {
        let { treatmentField, treatmentList } = this.state;
        console.log("uihwkjrwkej", name, value)
        treatmentField[name] = value;
        await this.setState({
            treatmentField,
        });
        if (name === "category") {
            this.props.getCommonApi(`stocklist/?Item_Deptid=${value}`).then((key) => {
                let { status, data } = key;
                if (status === 200) {
                    treatmentList = data;
                    this.setState({ treatmentList })
                }
            })
        }
        // this.props.updateForm('treatmentDetail', formFields)
    };

    handleChange = async ({ target: { value, name } }) => {
        let { formFields, selectedList } = this.state;
        console.log("uihwkjrwkej", name, value)
        formFields[name] = value;
        await this.setState({
            formFields,
        });
        selectedList.splice((selectedList.length - 1), 1);
        selectedList.push(formFields);
        await this.setState({
            selectedList,
        });
        console.log("sadfasdfasdf", selectedList)
        await this.props.updateForm('treatmentList', selectedList)
        // this.props.updateForm('treatmentDetail', formFields)
    };

    handleMultiSelect = (data) => {
        let { formFields } = this.state;
        let list = []
        for (let key of data) {
            list.push(key.value);
        }
        formFields['emp_no'] = list;
        this.setState({ formFields });
        console.log(formFields, "oyokkjk")
    }

    handleSubmit = () => {
        // this.props.handleConfirmBooking()
        let { appointmentCustomerDetail, appointmentTreatmentList } = this.props;
        console.log(appointmentCustomerDetail, appointmentTreatmentList, "sdfgdfsdggf")
        let data = {
            Appointment: {
                appt_date: dateFormat(new Date(appointmentCustomerDetail.appointmentDate), "yyyy-mm-dd"),
                Appt_typeid: appointmentCustomerDetail.Appt_typeid,
                cust_noid: appointmentCustomerDetail.customerName,
                new_remark: appointmentCustomerDetail.new_remark,
                // emp_noid: appointmentCustomerDetail.emp_id,
                Source_Codeid: appointmentCustomerDetail.Source_Codeid,
                Room_Codeid: appointmentCustomerDetail.Room_Codeid,
                appt_status: appointmentCustomerDetail.bookingStatus,
                sec_status: appointmentCustomerDetail.sec_status,
                ItemSite_Codeid: appointmentCustomerDetail.ItemSite_Codeid
            },
            Treatment: appointmentTreatmentList
        }
        this.props.commonCreateApi(`appointment/`, data).then(async (res) => {
            if (res.status === 201) {
                await this.props.updateForm('treatmentList', [])
                await this.props.updateForm('basicApptDetail', {})
                await this.props.updateForm('appointmentCustomerDetail', {})
                history.push('/admin/appointment')
            }
        })
    }

    getDateTime = (data) => {
        let date = new Date(data)
        date = String(date).split(" ")
        let date1 = date[2] + "th " + date[1] + ", " + date[3]
        let time = date[4].split(":")
        let time1 = String(Number(time[0]) > 12 ? (Number(time[0]) - 12) : time[0]) + ":" + time[1] + (Number(time[0]) > 12 ? "PM" : "AM")
        return time1 + ", " + date1
    }

    handleDialog = () => {
        this.setState({ isOpenModal: false });
    }

    handleMultipleCustomer = () => {
        this.setState({ isOpenModal: false });
    }

    handleSelectTreatment = async (data) => {
        let { treatmentList } = this.state;
        let { formFields, selectedList } = this.state;
        // console.log("uihwkjrwkej", data, formFields["start_time"], data.add_duration)
        formFields["start_time"] = formFields["start_time"];
        formFields["end_time"] = this.addTimes(formFields["start_time"], data.add_duration);
        formFields["Item_Codeid"] = data.id;
        formFields["Item_CodeName"] = data.item_desc;
        formFields["add_duration"] = data.add_duration;
        await this.setState({
            formFields,
        });
        selectedList.splice((selectedList.length - 1), 1);
        selectedList.push(formFields);
        await this.setState({
            selectedList,
        });
        // console.log("uihwkjrwkej", data, selectedList)
        await this.props.updateForm('treatmentList', selectedList)
        this.setState({ isOpenModal: false })
    }

    timeToMins = (time) => {
        var b = time.split(':');
        return b[0] * 60 + +b[1];
    }

    // Convert minutes to a time in format hh:mm
    // Returned value is in range 00  to 24 hrs
    timeFromMins = (mins) => {
        function z(n) { return (n < 10 ? '0' : '') + n; }
        var h = (mins / 60 | 0) % 24;
        var m = mins % 60;
        return z(h) + ':' + z(m);
    }

    // Add two times in hh:mm format
    addTimes = (t0, t1) => {
        return this.timeFromMins(this.timeToMins(t0) + this.timeToMins(t1));
    }

    handleAddtreatment = async () => {
        let { selectedList, formFields } = this.state;
        formFields = {
            start_time: selectedList[selectedList.length - 1].end_time,
            end_time: "",
            Item_Codeid: null,
            add_duration: "",
            emp_no: [],
            requesttherapist: false
        };
        selectedList.push({
            start_time: selectedList[selectedList.length - 1].end_time,
            end_time: "",
            Item_Codeid: 1,
            Item_CodeName: "",
            add_duration: "",
            emp_no: [],
            requesttherapist: false
        })

        console.log("uihwkjrwkej ======", formFields, selectedList, "/////////", selectedList[selectedList.length - 1].end_time)
        await this.setState({ selectedList, formFields });

        await this.props.updateForm('treatmentList', selectedList)
    }

    deleteTreatment = async (index) => {
        let { selectedList } = this.state;
        selectedList.splice(index, 1);
        this.setState({ selectedList });
        await this.props.updateForm('treatmentList', selectedList)
    }

    render() {
        let { outletOption, staffOption, roomOption, selectedList, siteList, list, formFields, timeDropdown, duration, isOpenModal, treatmentField, treatmentList = [], categoryList } = this.state
        let { customerDetail, selectedTreatmentList } = this.props;
        let { outlet, staff, rooms } = customerDetail;
        return (
            <div className="create-appointment select-treatment-appointment container">
                <div className="row">
                    <div className="col-md-1 pr-0 position-relative">
                        <div className="availability">
                            <p className="heading">Staff Availability</p>
                            {list.map((data, index) => (
                                <>
                                    <Availability availability={data}></Availability>
                                </>
                            ))}

                        </div>
                    </div>
                    <div className=" col-md-10 appointment-col">
                        <div className="appointment">
                            {/* <div className="timeline-view d-flex justify-content-around">
                            <div className="label-1 active"><div className="timeline step-1"></div><p>Customer Details</p></div>
                            <div className="label-2"><div className="timeline step-2"></div><p>Treatment</p></div>
                            <div className="label-3"><div cl3ssName="timeline step-3"></div><p>Book Appointment</p></div>
                            <div className="label-4"><div className="timeline"></div><p>Add to cart</p></div>
                        </div> */}
                            <div className="stepper">
                                <div className="step-view step-3">
                                    <div className="timeline-view select-treatment-timeline step d-flex justify-content-around">
                                        <div className=""><div className={``}><div className="timeline active"></div></div><p>Customer Details</p></div>
                                        <div className=""><div className={`visited`}><div className="timeline active"></div></div><p>Treatment</p></div>
                                        {/* <div className=""><div className={``}><div className="timeline"></div></div><p>Book Appointment</p></div>
                                        <div className=""><div className={``}><div className="timeline"></div></div><p>Add to cart</p></div> */}
                                    </div>
                                </div>
                            </div>
                            <div className="appointment-holder">
                                <div className="treatment-section">
                                    <div className="select-treatment select-list w-100">

                                        <div className="row selected selected-header mb-4">
                                            {/* <div className="col-7 p-0">
                                                <div className="row"> */}
                                            <div className="col-1 p-0">
                                                start
                                                    </div>
                                            <div className="col-1 p-0">
                                                end
                                                    </div>
                                            <div className="col-5 p-0 header-detail">
                                                Services
                                                    </div>
                                            {/* </div>
                                            </div> */}
                                            {/* <div className="col-3 p-0">
                                                <div className="row"> */}
                                            <div className="col-2 p-0 header-detail">
                                                Duration

                                                    </div>
                                            <div className="col-2 p-0">
                                                Treatment staff
                                                    </div>
                                            {/* </div>
                                            </div> */}
                                            {/* <div>

                                            </div> */}
                                        </div>
                                        {selectedList.length > 0 ? selectedList.map((item, index) => {
                                            return (
                                                <div className="row selected  mb-4">
                                                    {/* <div className="col-7 p-0">
                                                        <div className="row"> */}
                                                    <div className="col-1 p-0">
                                                        {/* <NormalSelect
                                                                    // placeholder="Enter here"
                                                                    options={timeDropdown}
                                                                    value={item.start_time}
                                                                    name="start_time"
                                                                    onChange={this.handleChange}
                                                                    className="customer-name p-0"
                                                                /> */}

                                                        <NormalInput
                                                            placeholder="start"
                                                            // options={timeDropdown}
                                                            value={item.start_time}
                                                            name="start_time"
                                                            onChange={this.handleChange}
                                                            className="customer-name p-0"
                                                            disabled={true}
                                                        />
                                                    </div>
                                                    <div className="col-1 p-0">
                                                        {/* <NormalSelect
                                                                    // placeholder="Enter here"
                                                                    options={timeDropdown}
                                                                    value={item.end_time}
                                                                    name="end_time"
                                                                    onChange={this.handleChange}
                                                                    className="customer-name p-0"
                                                                /> */}
                                                        <NormalInput
                                                            placeholder="end"
                                                            // options={timeDropdown}
                                                            value={item.end_time}
                                                            name="end_time"
                                                            onChange={this.handleChange}
                                                            className="customer-name p-0"
                                                            disabled={true}
                                                        />
                                                    </div>
                                                    <div className="col-5 p-0">
                                                        <div className="header-detail"></div>
                                                        <NormalInput
                                                            placeholder="service"
                                                            // options={siteList}
                                                            value={item.Item_CodeName}
                                                            name="Item_CodeName"
                                                            onClick={() => this.setState({ isOpenModal: true })}
                                                            className="customer-name p-0 px-2"
                                                        />
                                                        {/* </div>
                                                        </div> */}
                                                    </div>
                                                    {/* <div className="col-3 p-0">
                                                        <div className="row"> */}
                                                    <div className="col-2 p-0 header-detail">
                                                        <NormalSelect
                                                            // placeholder="Enter here"
                                                            options={duration}
                                                            value={item.add_duration}
                                                            name="add_duration"
                                                            onChange={this.handleChange}
                                                            className="customer-name p-0"
                                                        />

                                                    </div>
                                                    <div className="col-2 p-0">
                                                        <NormalSelect
                                                            // placeholder="Enter here"
                                                            options={staffOption}
                                                            value={item.emp_no}
                                                            name="emp_no"
                                                            onChange={this.handleChange}
                                                            className="customer-name p-0"
                                                        />
                                                        {/* {staffOption.length > 0 ? <NormalMultiSelect 
                                                                name="emp_no" 
                                                                className={`staff-skills-select ${item.emp_no !== "" ? "overflow-y-set" : ""}`} 
                                                                options={staffOption} 
                                                                isMulti={false}
                                                                handleMultiSelect={this.handleMultiSelect}>

                                                                </NormalMultiSelect> : "" 

                                                                } */}
                                                        {/* </div>
                                                        </div> */}
                                                    </div>
                                                    {selectedList.length === index + 1 ?
                                                        <div className="ml-3" onClick={this.handleAddtreatment}>
                                                            <svg width="31" height="30" viewBox="0 0 31 30" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                <rect width="31" height="30" fill="#F9F9F9" />
                                                                <path d="M15 8V22" stroke="#848484" stroke-linecap="round" stroke-linejoin="round" />
                                                                <path d="M8 15H22" stroke="#848484" stroke-linecap="round" stroke-linejoin="round" />
                                                            </svg>
                                                        </div> : <img width="25" height="25" onClick={() => this.deleteTreatment(index)} className="ml-3" src={closeIcon} alt="" />}
                                                </div>
                                            )
                                        }) : ""}

                                        <div className="confirm confirm-selected mt-5">
                                            <NormalButton
                                                buttonClass={"treatment"}
                                                mainbg={true}
                                                className="col-12 mr-5 fs-15 "
                                                label="cancel"
                                                onClick={() => history.push('/admin/appointment')}
                                            />
                                            <NormalButton
                                                buttonClass={"treatment"}
                                                mainbg={true}
                                                className="col-12 ml-4 fs-15 "
                                                label="Confirm Booking"
                                                onClick={this.handleSubmit}
                                            />
                                        </div>
                                    </div>
                                </div>
                                {/* <div className="view-all-appointment">
                                    <NormalButton
                                        buttonClass={"treatment"}
                                        mainbg={true}
                                        className="col-12 fs-15 "
                                        label="View all"
                                        onClick={() => this.setState({ activeTab: "confirm-booking" })}
                                    />
                                </div> */}
                            </div>
                        </div>
                    </div>
                    <Cart />
                </div>

                <NormalModal className={"multiple-appointment select-category"} style={{ minWidth: "800px" }} modal={isOpenModal} handleModal={this.handleDialog}>
                    <img onClick={this.handleDialog} className="close" src={closeIcon} alt="" />
                    <div className="row mt-2 mb-5 mx-3">
                        <div className="col-12 pl-0 mb-3 fs-18 py-2">
                            Select Treatment
                        </div>
                        Category
                        <NormalSelect
                            // placeholder="Enter here"
                            options={categoryList}
                            value={treatmentField.category}
                            name="category"
                            onChange={this.handleChangeTreatment}
                            className="customer-name p-0"
                        />
                        Service
                        <NormalInput
                            // placeholder="Enter here"
                            // options={siteList}
                            value={treatmentField.treatment}
                            name="treatment"
                            onClick={() => this.setState({ isOpenModal: true })}
                            onChange={this.handleChangeTreatment}
                            className="search px-3 p-0"
                        />

                        <div className="row mt-4 table-header w-100 m-0">
                            <div className="col-2">Category</div>
                            <div className="col-6">Service</div>
                            <div className="col-2">Duration</div>
                            <div className="col-2">price</div>
                        </div>
                        <div className="response-table w-100">
                            {treatmentList.length > 0 ? treatmentList.map((item, index) => {
                                return (
                                    <div className="row m-0 table-body w-100" onClick={() => this.handleSelectTreatment(item)} key={index}>
                                        <div className="col-2">{item.Item_Class}</div>
                                        <div className="col-6">{item.item_desc}</div>
                                        <div className="col-2">{item.add_duration}</div>
                                        <div className="col-2">{item.item_price}</div>
                                    </div>
                                )
                            }) : <div className="text-center w-100">
                                    No data are available
                        </div>}
                        </div>
                        {/* <div className="d-flex create m-5 w-100">
                            <NormalButton
                                buttonClass={"mx-2"}
                                mainbg={true}
                                className="col-12 fs-15 multiple-customer"
                                label="Continue"
                                outline={true}
                                onClick={this.handleMultipleCustomer}
                            />
                        </div> */}


                    </div>
                </NormalModal>
            </div>
        );
    }
}

const mapStateToProps = (state) => ({
    customerDetail: state.appointment.customerDetail,
    appointmentDetail: state.appointment.appointmentDetail,
    selectedTreatmentList: state.appointment.selectedTreatmentList,
    basicApptDetail: state.appointment.basicApptDetail,
    appointmentCustomerDetail: state.appointment.appointmentCustomerDetail,
    appointmentTreatmentList: state.appointment.appointmentTreatmentList,
})

const mapDispatchToProps = dispatch => {
    return bindActionCreators({
        updateForm,
        getSelectedTreatmentList,
        getCommonApi,
        commonCreateApi
    }, dispatch)
}

export const SelectTreatment = connect(mapStateToProps, mapDispatchToProps)(SelectTreatmentClass)