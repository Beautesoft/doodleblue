import React, { Component } from 'react'
import { NormalInput, NormalSelect, NormalButton, NormalDate, NormalModal } from 'component/common';
import SimpleReactValidator from 'simple-react-validator';
import { Link } from 'react-router-dom';
import closeIcon from '../../../../assets/images/close.png';
import { AppointmentForm } from './AppointmentForm';
import { CreateAppointment, updateForm } from 'redux/actions/appointment';
import { getCustomer, getCommonApi } from 'redux/actions/common';
import { connect } from 'react-redux';
import { bindActionCreators } from "redux";
import timeOption from 'data/timeOption.json'
import { dateFormat } from 'service/helperFunctions';
import { history } from 'helpers';
import { Button, Form, FormGroup, Label, Input, FormText } from 'reactstrap';

export class CustomerAppointmentClass extends Component {
    state = {
        active: false,
        appt_fr_time: '',
        appt_to_time: "",
        currentValue: '-1',
        formFields: {
            customerName: "",
            emp_id: "",
            appointmentDate: "",
            appt_fr_time: "",
            appt_to_time: "",
            bookingStatus: "",
            Source_Codeid: "",
            ItemSite_Codeid: ""
        },
        multipleCustomerForm: {
            noOfCustomer: 1,
            treatment: "",
            room: ""
        },
        bookingList: [],
        isOpenModal: false,
        multipleCustomr: 1,
        customerElement: [],
        siteList: [],
        sourceList: [],
        staffList: []
    }

    componentWillMount() {
        this.validator = new SimpleReactValidator({
            element: message => <span className="error-message text-danger validNo fs14">{message}</span>,
            autoForceUpdate: this,
        });
        this.props.getCustomer('all/').then(() => { })
        this.props.getCommonApi('bookingstatus/').then((res) => {
            let { status, data } = res;
            if (status === 200) {
                this.setState({ bookingList: data })
            }
        })
        this.handleCustomerElement()
        this.getListData();
    }

    getListData = () => {
        let { staffList, sourceList, siteList } = this.state;
       
        this.props.getCommonApi(`source/`).then((key) => {
            let { status, data } = key;
            if (status === 200) {
                for (let value of data) {
                    sourceList.push({ value: value.id, label: value.source_desc })
                }
                this.setState({ sourceList })
                console.log(sourceList, "jhksdfkjsdhfks")
            }
        })
        this.props.getCommonApi(`treatment/Outlet/`).then((key) => {
            let { status, data } = key;
            if (status === 200) {
                for (let value of data) {
                    siteList.push({ value: value.id, label: value.itemsite_code })
                }
                this.setState({ siteList })
                console.log(siteList, "jhksdfkjsdhfks")
            }
        })
    }

    selectTime = async (key, type) => {
        let { formFields } = this.state;
        if (type === "appt_fr_time") {
            formFields['appt_fr_time'] = key;
            await this.setState({
                formFields,
                appt_fr_time: key
            })
        } else {
            formFields['appt_to_time'] = key;
            await this.setState({
                formFields,
                appt_to_time: key
            })
        }

        await this.props.updateForm('customerDetail', formFields)
        console.log("sdfsdfsdfsd", formFields)
    }

    handleClick = (key) => {
        if (!this.state.active) {
            document.addEventListener('click', this.handleOutsideClick, false);
        } else {
            document.removeEventListener('click', this.handleOutsideClick, false);
        }

        this.setState(prevState => ({
            active: !prevState.active,
            currentValue: key
        }));
    }

    handleOutsideClick = (e) => {
        if (this.node != null) {
            if (this.node.contains(e.target)) {
                return;
            }
        }
        this.handleClick();
    }

    handleChange = async ({ target: { value, name } }) => {
        let { formFields } = this.state;
        formFields[name] = value;
        await this.setState({
            formFields,
        });
        this.props.updateForm('customerDetail', formFields)
        if(name==="ItemSite_Codeid"){
            let { staffList } = this.state;
            this.props.getCommonApi(`appointment/Staffs/?Outlet=${value}`).then((key) => {
                let { status, data } = key;
                if (status === 200) {
                    for (let value of data) {
                        staffList.push({ value: value.id, label: value.emp_name })
                    }
                    this.setState({ staffList })
                }
            })
        }
    };

    handleMultiple = async ({ target: { value, name } }) => {
        let { multipleCustomerForm } = this.state;
        if (name === "noOfCustomer") {
            multipleCustomerForm[name] = Number(value);
        }
        if (name === "sameForAllTreatment" || name === "differentForAllTreatment") {
            if (name === "differentForAllTreatment") {
                multipleCustomerForm['treatment'] = 2;
            } else {
                multipleCustomerForm['treatment'] = 1;
            }
        } else {
            if (name === "differentForAllRoom") {
                multipleCustomerForm['room'] = 2;
            } else {
                multipleCustomerForm['room'] = 1;
            }
        }

        await this.setState({
            multipleCustomerForm,
        });
        this.props.updateForm('multipleCustomerForm', multipleCustomerForm)
    }

    handleSubmit = () => {
        let { customerDetail } = this.props;
        if (this.validator.allValid()) {
            let data = {
                cust_noid: Number(customerDetail.customerName),
                emp_noid: Number(customerDetail.emp_id),
                appt_date: dateFormat(customerDetail.appointmentDate, "yyyy-mm-dd"),
                // Appt_Fr_time: this.getTime(customerDetail.appt_fr_time),
                appt_fr_time: customerDetail.appt_fr_time,
                appt_to_time: customerDetail.appt_to_time,
                appt_Status: customerDetail.bookingStatus,
                Source_Codeid: customerDetail.Source_Codeid,
                ItemSite_Codeid: customerDetail.ItemSite_Codeid
            }
            this.props.CreateAppointment(data).then((res) => {
                if (res.status === 201) {
                    history.push(`/admin/appointment/create/treatment`)
                }
            })
        } else {
            this.validator.showMessages();
        }
    }

    getTime = (data) => {
        let time = data.split(" ")
        let time1 = time[0].split(":")
        console.log(time, time1, "kghjhgdjfgsdf")
        if (time[1] === "pm") {
            return ((Number(time1[0]) + 12) === 24 ? "00" : Number(time1[0]) + 12) + ":" + time1[1]
        } else {
            return time1[0] < 9 ? ("0" + time[0]) : time1[0] + ":" + time1[1]
        }
    }

    handleDialog = () => {
        let { isOpenModal } = this.state;
        isOpenModal = !isOpenModal;
        this.setState({
            isOpenModal
        })
    }

    handleCustomerElement = async (count) => {
        let { appt_fr_time, appt_to_time, active, currentValue, bookingList, siteList, sourceList, staffList, multipleCustomr, customerElement } = this.state;
        let { customerDetail, customerList, multipleCustomerForm } = this.props;
        console.log(this.props, this.state, "dkjfkshgfghdfk =======", customerList)
        for (let i = 0; multipleCustomr > i; i++) {
            customerElement.push(
                <div className="customer-appointment my-3 multiple">
                    <p className="customer-label">Customer Detail</p>
                    <AppointmentForm>
                    </AppointmentForm>
                    <div className="d-flex create">
                        <NormalButton
                            buttonClass={"mx-2"}
                            mainbg={true}
                            className="col-12 fs-15 confirm"
                            label="Select treatment"
                            onClick={this.handleSubmit}
                        />
                    </div>
                </div>)
        }
        this.setState({ customerElement, isOpenModal: false })
        console.log(multipleCustomerForm, this.state, "dkjfkshgfghdfk =======", multipleCustomerForm.noOfCustomer, customerElement)

    }

    handleMultipleCustomer = async () => {
        let { multipleCustomerForm } = this.props;
        await this.setState({ multipleCustomr: multipleCustomerForm.noOfCustomer, customerElement: [] })
        console.log(multipleCustomerForm, this.state, "dkjfkshgfghdfk", multipleCustomerForm.noOfCustomer)
        this.handleCustomerElement(multipleCustomerForm.noOfCustomer);
    }

    render() {
        let { appt_fr_time, active, currentValue, bookingList, isOpenModal, multipleCustomr, appt_to_time, siteList, sourceList, staffList, customerElement } = this.state;
        let { customerDetail, customerList, multipleCustomerForm } = this.props;
        let { noOfCustomer, treatment, room } = multipleCustomerForm;
        return (
            <div className="appointment-holder">
                
                 
                            <AppointmentForm>
                            </AppointmentForm>
                


                <NormalModal className={"multiple-appointment"} modal={isOpenModal} handleModal={this.handleDialog}>
                    <img onClick={this.handleDialog} className="close" src={closeIcon} alt="" />
                    <div className="row m-5">
                        <div className="col-8 py-2">
                            Select The Number Of Customer
                        </div>
                        <div className="col-4 ">
                            <div className="input-group">
                                <NormalSelect
                                    // placeholder="Enter here"
                                    options={[{ label: "1", value: 1 }, { label: "2", value: 2 }, { label: "3", value: 3 }, { label: "4", value: 4 }]}
                                    value={noOfCustomer}
                                    name="noOfCustomer"
                                    onChange={this.handleMultiple}
                                    className="customer-name status"
                                />
                            </div>
                        </div>
                        <div className="col-12 my-3"> Treatment</div>
                        <div className="col-6">
                            <FormGroup check>
                                <Label check>
                                    <Input type="radio" name="sameForAllTreatment" onChange={this.handleMultiple} />
                                    {' '} Same For All
                                </Label>
                            </FormGroup>
                        </div>
                        <div className="col-6">
                            <FormGroup check>
                                <Label check>
                                    <Input type="radio" name="differentForAllTreatment" onChange={this.handleMultiple} />{' '}
                                        Different For All
                                    </Label>
                            </FormGroup></div>

                        <div className="col-12 my-3"> Rooms</div>
                        <div className="col-6">
                            <FormGroup check>
                                <Label check>
                                    <Input type="radio" name="sameForAllRoom" onChange={this.handleMultiple} />
                                    {' '} Same For All
                                </Label>
                            </FormGroup>
                        </div>
                        <div className="col-6">
                            <FormGroup check>
                                <Label check>
                                    <Input type="radio" name="differentForAllRoom" onChange={this.handleMultiple} />{' '}
                                        Different For All
                                    </Label>
                            </FormGroup>
                        </div>
                        <div className="d-flex create mt-5 w-100">
                            <NormalButton
                                buttonClass={"mx-2"}
                                mainbg={true}
                                className="col-12 fs-15 multiple-customer"
                                label="Continue"
                                outline={true}
                                onClick={this.handleMultipleCustomer}
                            />
                        </div>
                    </div>
                </NormalModal>
            </div>


        );
    }
}


const mapStateToProps = (state) => ({
    customerDetail: state.appointment.customerDetail,
    customerList: state.common.customerList,
    multipleCustomerForm: state.appointment.multipleCustomerForm
})

const mapDispatchToProps = dispatch => {
    return bindActionCreators({
        CreateAppointment,
        updateForm,
        getCustomer,
        getCommonApi
    }, dispatch)
}

export const CustomerAppointment = connect(mapStateToProps, mapDispatchToProps)(CustomerAppointmentClass)