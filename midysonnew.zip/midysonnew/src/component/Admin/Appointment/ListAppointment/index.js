import React from 'react';
import { NormalButton, NormalSelect, NormalInput } from 'component/common';
import { InputSearch, TableWrapper } from 'component/common';
import { Scheduler } from './Scheduler/index'
import './style.scss'
export class ListAppointment extends React.Component {
    state={
        formFields: {
          salon:'',
            salonOption: [
                { label: 'ABC', value: 'ABC' },
                { label: 'XYZ', value: 'XYZ' },
                { label: 'PQR', value: 'PQR' },
            ],
        }
    }

    handleChange = ({ target: { value, name } }) => {
        let formFields = Object.assign({}, this.state.formFields);

        formFields[name] = value;

        this.setState({
            formFields,
        });
    };

    handleClick = (key) => {
        let currentIndex;
        if (this.state.active === true) {
            this.setState({
                active: false,
                currentIndex: '-1'
            })
        }
        else {
            this.setState({
                active: true,
                currentIndex: key
            })
        }
    }
    render() {
        let { formFields, search="" } = this.state;
        let { salon, salonOption } = formFields
        return (
            <>
                {/* <div className="row align-items-center">
                    <div className="col-md-7">
                        <h3>Appointments</h3>
                    </div>
                    <div className="col-md-5 d-flex justify-content-end">
                        <div className="w-100 col-4 p-0">
                            <NormalButton
                                mainbg={true}
                                className="col-12 fs-15 "
                                label="Book Appointment"
                                onClick={() => this.props.history.push('/admin/appointment/create')}
                            />
                        </div>
                    </div>
                </div> */}
                {/* <div>
                    <div className="salon-appointment px-0 row m-0"> */}
                        {/* <div className="salon-name">Salons</div> */}
                        {/* <div className="p-0 col-3 pr-3">
                            <NormalButton
                                mainbg={true}
                                className="col-12 fs-15"
                                label="Book Appointment"
                                onClick={() => this.props.history.push('/admin/appointment/create')}
                            />
                        </div>
                        <div className="input-group appointment-salon col-3">
                        <NormalSelect
                            options={salonOption}
                            value={salon}
                            name="salon"
                            onChange={this.handleChange}
                            iconname="icon-down-key"
                        />
                        </div>
                        <div className="input-group col-2">
                            <InputSearch
                            placeholder="Enter here"
                            value={search}
                            name="search"
                            onChange={this.handleChange}
                            />
                        </div> */}
                    {/* </div>
                </div> */}
                <div className="">
                    <Scheduler />
                </div>

            </>
        );
    }
}