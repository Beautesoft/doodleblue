import React, { Component } from 'react';
import { SchedulerModal } from 'component/common/Plugins';
// import BigSchedulerModal from 'component/common/Plugins/BigScheduler';
import { NormalInput, NormalSelect, NormalButton, NormalDate, NormalModal } from 'component/common';
import { getCustomer, getCommonApi } from 'redux/actions/common';
import { connect } from 'react-redux';
import { bindActionCreators } from "redux";
import timeOption from 'data/timeOption.json'
import { dateFormat } from 'service/helperFunctions';
import { history } from 'helpers';
import './style.scss';
import SimpleReactValidator from 'simple-react-validator';
import { CreateAppointment, updateForm } from 'redux/actions/appointment';

const data = [
    { start_date: '2020-06-09 4:00', end_date: '2020-06-09 6:00', text: 'Event 1', id: 1 },
    { start_date: '2020-06-11 8:00', end_date: '2020-06-11 10:00', text: 'Event 2', id: 2 },
    { start_date: '2020-06-12 12:00', end_date: '2018-06-12 14:00', text: 'dblclick me!', id: 3 }
];

export class SchedulerClass extends Component {
    state = {
        appointment: [
            {
                time: '10.00 AM,',
                date: 'Wednesday, 1st April, 2020',
                name: 'Benjamin',
                treatment: 'Head Massage'
            },
            {
                time: '12.00 PM,',
                date: 'Wednesday, 1st April, 2020',
                name: 'Daniel',
                treatment: 'Pedicure'
            },
            {
                time: '1.00 PM,',
                date: 'Wednesday, 1st April, 2020',
                name: 'John',
                treatment: 'Haircut'
            },
            {
                time: '2.00 PM,',
                date: 'Wednesday, 1st April, 2020',
                name: 'Josua',
                treatment: 'Manicure'
            },
            {
                time: '4.00 PM, ',
                date: 'Wednesday, 1st April, 2020',
                name: 'Derrik',
                treatment: 'Body Massage'
            },

        ],
        events: [
            // { start_date: '2020-09-16 4:00', end_date: '2020-09-16 6:00', text: 'Event 1', id: 1, user_id: 5 },
            // // { start_date: '2020-06-10 6:00', end_date: '2018-06-10 8:00', text: 'Event 2', id: 2 },
            // { start_date: '2020-09-17 8:00', end_date: '2020-09-17 10:00', text: 'Event 2', id: 3, user_id: 5 },
            // { start_date: '2020-09-18 8:00', end_date: '2020-09-18 10:00', text: 'Event 3', id: 5, user_id: 5 },
            // { start_date: '2020-09-19 8:00', end_date: '2020-09-19 10:00', text: 'Event 3', id: 6, user_id: 5 },
            // { start_date: '2020-09-20 8:00', end_date: '2020-09-20 10:00', text: 'Event 3', id: 7, user_id: 5 },
            // { start_date: '2020-09-14 8:00', end_date: '2020-09-14 10:00', text: 'Event 3', id: 8, user_id: 5 },
            // { start_date: '2020-09-15 8:00', end_date: '2020-09-15 10:00', text: 'Event 3', id: 9, user_id: 5 }

//             {start_date: "2020-09-15 9:00", end_date: "2020-09-15 11:30", text: "1 X 360 Glow Treatment - IPL Facial", id: 86, user_id: 4},
// {start_date: "2020-09-15 7:00", end_date: "2020-09-15 9:30", text: "1 X 360 Glow Treatment - IPL Facial", id: 84, user_id: 4},
// {start_date: "2020-09-15 9:00", end_date: "2020-09-15 11:30", text: "1 X 360 Glow Treatment - IPL Facial", id: 83, user_id: 4},
// {start_date: "2020-09-15 7:00", end_date: "2020-09-15 9:30", text: "1 X 360 Glow Treatment - IPL Facial", id: 85, user_id: 7}

        ],
        brachList: [],
        formField: {
            branchId: "",
            time: ""
        },
        list: []
    }

    componentWillMount = () => {
        this.validator = new SimpleReactValidator({
            element: message => <span className="error-message text-danger validNo fs14">{message}</span>,
            autoForceUpdate: this,
        });
        let { brachList, appointment, formField } = this.state;
        this.props.getCommonApi(`treatment/Outlet/`).then((key) => {
            let { status, data } = key;
            if (status === 200) {
                for (let value of data) {
                    brachList.push({ value: value.id, label: value.itemsite_desc })
                }
                this.setState({ brachList })
                // console.log(brachList, "jhksdfkjsdhfks")
            }
        })
        this.props.getCommonApi(`staffsavailable/?Appt_date=${dateFormat(new Date(), "yyyy-mm-dd")}`).then((key) => {
            let { status, data } = key;
            if (status === 200) {
                // for (let value of data) {
                //     staffList.push({ value: value.id, label: value.emp_name })
                // }
                this.setState({ list:data })
            }
        })
    }

    handleAppointmentOpen = (id, e) => {
        console.log(e, id, "hgjsydfisuyfsdfm ====");
    }

    handleEmptyEvent = async (date, e) => {
        let { customerDetail } = this.props;
        let { formField } = this.state;
        if (this.validator.allValid()) {
            let time = new Date(date)
            formField['time'] = time.getHours() > 9 ? (time.getHours() + ":00"):("0"+ time.getHours()) + ":00";
            await this.setState({ formField });
            console.log(date, e, "hgjsydfisuyfsdfm ====", time.getHours);
            await this.props.updateForm('basicApptDetail', formField);
            history.push(`/admin/appointment/create`)
            // console.log(date, e, "hgjsydfisuyfsdfm ====");
        } else {
            this.validator.showMessages();
        }

    }

    getAppointment = () => {
        let { brachList, events, formField } = this.state;
        this.props.getCommonApi(`appointmentcalender/?date=${dateFormat(new Date())}&site_id=${formField.branchId}&check=day`).then(async(key) => {
            let { status, data } = key;
            if (status === 200) {
                await this.setState({ events: null })
                events = data;
                await this.setState({ events })
                console.log(events, "jhksdfkjsdhfks", key)
            }
        })
    }

    handleChange = async ({ target: { value, name } }) => {
        let { formField } = this.state;
        formField[name] = value;
        await this.setState({
            formField,
        });
        if(name==="branchId"){
            this.getAppointment();
        }
        console.log(formField, "afasfasdfdfasd")
        this.props.updateForm('basicApptDetail', formField);
    };

    render() {
        let { appointment, brachList, branchId, formField, list, events } = this.state;
        return (
            <div className="row m-0">

                <div className="col-3 pl-0 ">
                    <div className="position-relative scheduler">
                        <div className="schedule-label">
                            Today's Appointments
                        </div>
                        {/* <span className="icon-down-blue clip-icon"></span> */}
                    </div>
                    <div className="appointment appointment-available-staff">
                        {list && list.map((data, index) => (
                            <>
                                <div className="row p-3">
                                    <div className="col-3 text-right time profile">
                                        {/* <p>{data.time}</p>
                                    <p className="meridiem">{data.meridiem}</p> */}
                                        <svg width="40" height="40" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <circle cx="20" cy="20" r="20" fill="$primary-color" />
                                            <path d="M15.9593 27.492V26.498C16.538 26.6007 16.9953 26.624 17.3313 26.568C17.6673 26.5213 17.9053 26.358 18.0453 26.078C18.1853 25.8073 18.2553 25.3967 18.2553 24.846V15.032H19.4033V24.86C19.4033 25.6347 19.2913 26.2367 19.0673 26.666C18.8433 27.1047 18.4793 27.3847 17.9753 27.506C17.4713 27.6367 16.7993 27.632 15.9593 27.492ZM20.2933 27.492V26.498C20.8719 26.6007 21.3293 26.624 21.6653 26.568C22.0013 26.5213 22.2393 26.358 22.3793 26.078C22.5193 25.8073 22.5893 25.3967 22.5893 24.846V15.032H23.7373V24.86C23.7373 25.6347 23.6253 26.2367 23.4013 26.666C23.1773 27.1047 22.8133 27.3847 22.3093 27.506C21.8053 27.6367 21.1333 27.632 20.2933 27.492Z" fill="white" />
                                        </svg>

                                    </div>
                                    <div className="col-8 detail">
                                        {/* <p className="name">{data.name}</p>
                                    <p className="treatment">{data.treatment}</p> */}
                                        <p className="title mb-0">{data.emp_name}</p>
                                        <p className="head-message mb-0">{data.job_title}</p>
                                        <p className="date mb-0">{data.time}</p>
                                        <p className="date mb-0">{data.date}</p>
                                    </div>
                                </div>
                                <div className="border-bottom-line mx-3"></div>
                            </>
                        ))}
                    </div>
                </div>
                <div className='scheduler-container col-9 pr-0'>
                    <div className="col-3 mb-3 p-0">
                        <div>
                            <label className="text-left text-black common-label-text ">
                                Branch
                            </label>
                        </div>
                        <div className="input-group">
                            <NormalSelect
                                // placeholder="Enter here"
                                options={brachList}
                                value={formField.branchId}
                                name="branchId"
                                onChange={this.handleChange}
                                className="customer-name"
                            />
                        </div>
                        {this.validator.message('branch', formField.branchId, 'required')}
                    </div>
                    {events ? 
                    <SchedulerModal events={events} onClick={(id, e) => this.handleAppointmentOpen(id, e)} onEmptyClick={(date, e) => this.handleEmptyEvent(date, e)} />:""}
                    {/* <div style={{flex: 1}}> */}
                    {/* <BigSchedulerModal></BigSchedulerModal> */}
                    {/* </div> */}

                </div>
            </div>
        );
    }
}

const mapStateToProps = (state) => ({
    customerDetail: state.appointment.customerDetail,
    customerList: state.common.customerList,
    multipleCustomerForm: state.appointment.multipleCustomerForm
})

const mapDispatchToProps = dispatch => {
    return bindActionCreators({
        getCustomer,
        getCommonApi,
        updateForm
    }, dispatch)
}

export const Scheduler = connect(mapStateToProps, mapDispatchToProps)(SchedulerClass)