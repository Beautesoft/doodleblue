import React, { Component } from 'react';
import { NormalButton, NormalTextarea } from 'component/common';
import Modal from "../../../../assets/images/modal-avatar.png";
import './style.scss';
export class AppointmentDetail extends Component {
    state = {
        formFields: {
            feedback: '',
        },
        userDetail: [
            { label: 'Joined', value: '02.05.2020' },
            { label: 'D.O.B', value: '02.05.1995' },
            { label: 'Gender', value: 'Female' },
            { label: 'Phone', value: '+65 62970125' },
            { label: 'Email', value: 'jamie@gmail.com' },
            { label: 'Address', value: '1/2, Jurong west, Singapore.' },
            { label: 'Member type', value: 'Premium' },
        ],
    }
    handleInput = ({ target: { name, value } }) => {

        let formFields = Object.assign({}, this.state.formFields)
        formFields[name] = (value === true ? 1 : value);
        this.setState({
            formFields
        })

    }
    render() {
        let { formFields, userDetail } = this.state
        let { feedback } = formFields
        return (
            <>
                <div className="appointment-detail">
                    <div className="row">
                        <div className="col-md-9">
                            <div className="re-direct">
                                <i className="icon-left-arrow"></i>
                                <p>Back to appointments</p>
                            </div>
                            <p className="head-label">Appointment details</p>
                            <div className="appointment">
                                <table className="table">
                                    <thead>
                                        <tr>
                                            <th className="first-value">Date</th>
                                            <th>Time</th>
                                            <th>Outlet</th>
                                            <th>Treatment</th>
                                            <th>Booking Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>20.04.2020 Monday</td>
                                            <td>4:00 PM</td>
                                            <td>Jurong (Bioskin)</td>
                                            <td>Golden facial (60 mins) F0001325</td>
                                            <td className="appointment-status">Waitlist</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                            <div className="status">
                                <p className="status-label">Customer request</p>
                                <p className="status-detail">Customer has requested for special towel</p>
                            </div>
                            <div className="status">
                                <p className="status-label">Payment </p>
                                <p className="status-detail">Debit card (paid)</p>
                            </div>
                            <p className="head-label">Treatment</p>
                            <div className="appointment">
                                <table className="table">
                                    <thead>
                                        <tr>
                                            <th className="first-value">Start time</th>
                                            <th>End Time</th>
                                            <th>Therapist(s)</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>20.04.2020 Monday</td>
                                            <td>4:00 PM</td>
                                            <td>Jurong (Bioskin)</td>
                                            <td className="appointment-status">Not completed</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                            <p className="head-label">Remarks</p>
                            <div className="d-flex pt-3">
                                <i className="icon-star ml-3"></i>
                                <i className="icon-star pl-1"></i>
                                <i className="icon-star pl-1"></i>
                                <i className="icon-star pl-1"></i>
                                <i className="icon-star pl-1"></i>
                            </div>
                            <div className="my-4">
                                <NormalTextarea
                                    placeholder="Enter customer feedbacks..."
                                    value={feedback}
                                    name="feedback"
                                    onChange={this.handleInput}
                                />
                            </div>

                            <div className="d-flex justify-content-center">
                                <div className="col-2">
                                    <NormalButton label="Submit" success={true} className="mr-2 col-12" />
                                </div>
                            </div>

                        </div>
                        <div className="col-md-3">
                            <div className="detail-card card">
                                <div className="detail-user-profile">
                                    <div className="profile-avatar">
                                        <img className="modal-avatar" src={Modal} />
                                    </div>
                                    <p className="user-name text-center">Jamie James</p>
                                    <NormalButton label="Id : 123456789" className="mr-2 col-12" />
                                </div>
                                <div className="user-detail">
                                    {
                                        userDetail.map((data, index) => (
                                            <div className="detail d-flex" key={index}>
                                                <p className="status-label">{data.label}</p>
                                                <p className="spliter">:</p>
                                                <p className="status-detail">{data.value}</p>
                                            </div>
                                        ))
                                    }

                                </div>


                            </div>
                        </div>
                    </div>
                </div>
            </>
        );
    }
}