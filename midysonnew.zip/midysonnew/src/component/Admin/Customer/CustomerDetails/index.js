export { CustomerDetails } from './CustomerDetail'
export { AccountDetails } from './AccountDetail'
export { TreatmentDetails } from './TreatmentDetail'
export { TreatmentCourseDetails } from './TreatmentHistory/index.js'