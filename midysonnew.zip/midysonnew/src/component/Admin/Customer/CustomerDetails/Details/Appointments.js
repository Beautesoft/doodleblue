import React, { Component } from 'react';
export class Appointments extends Component {
    render() {
        return (
             <>
             </>
        );
    }
}