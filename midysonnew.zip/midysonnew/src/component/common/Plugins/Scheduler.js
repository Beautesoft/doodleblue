import React, { Component } from 'react';
import 'dhtmlx-scheduler';
import 'dhtmlx-scheduler/codebase/dhtmlxscheduler_material.css';

const scheduler = window.scheduler;

export class SchedulerModal extends Component {
    componentDidMount() {
        console.log(this.props, "dsfsdfgdfgsdfgsdf")
        scheduler.skin = 'material';
        scheduler.config.header = [
            'day',
            'week',
            'month',
            'date',
            'prev',
            'today',
            'next'
        ];

        let { events, onClick, onEmptyClick } = this.props;
        scheduler.init(this.schedulerContainer, new Date(), 'day');
        scheduler.clearAll();
        scheduler.config.resource_property = "user_id";
        scheduler.parse(
            events
        );
        scheduler.attachEvent("onClick", function (id, e) {
            //any custom logic here
            onClick(id, e)
            console.log(e, id, "hgjsydfisuyfsdfm ====")
            return true;
        });
        scheduler.attachEvent("onEmptyClick", function (date, e){
            onEmptyClick(date, e)
            console.log(date, e, "hgjsydfisuyfsdfm ====  ----")
     });
    }

    render() {
        return (
            <div
                ref={(input) => { this.schedulerContainer = input }}
                style={{ width: '100%', height: '100%' }}
            ></div>
        );
    }
}