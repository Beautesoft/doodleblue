import React, { Component } from "react";
import { Navbar } from "component/Header";
import { Sidebar } from "component/Sidebar";
import "assets/scss/layouts/mainlayout.scss";
import "react-perfect-scrollbar/dist/css/styles.css";
import PerfectScrollbar from "react-perfect-scrollbar";

export class MainLayout extends Component {
  state = {
    profilemenu: false,
    menuOpenClass: false
  };

  handleProfileMenu = (event, active) => {
    event.stopPropagation();
    this.setState({
      profilemenu: active
    });
  };

  handleSidenav = () => {
    let { menuOpenClass } = this.state;

    this.setState({
      menuOpenClass: !menuOpenClass
    });
  };

  render() {
    let { children } = this.props;

    let { menuOpenClass } = this.state;

    return (
      <div id="main-content" onClick={e => this.handleProfileMenu(e, false)}>
        <div className="nav-head">
        <Navbar
          changeProfileState={(e, param) => this.handleProfileMenu(e, param)}
          active={this.state.profilemenu}
        />
        <Sidebar
            menuOpen={menuOpenClass}
            handleSidenav={this.handleSidenav}
          />
          </div>
        <div className="content-wrapper">
          <PerfectScrollbar>
            <div className="content">{children}</div>
          </PerfectScrollbar>
        </div>
   <center><h6 
   style={{backgroundColor: "#ecececb8"}}>
     Copyrights (c) Acy7lab.com. Licensed to Sequoia 
     - Version 3.16</h6> </center>
      </div>
    );
  }
}
