import React from "react";
import {
  QuickStats,
  CustomerStats,
  StaffServices,
  IncomeStats,
  SalesBySalon,
  SalesByProduct,
  SalesByCategory,
  CustomerByCountry,
  InvoicesStats,
  Logs,
  NewQuickStats,
  NewQuickChart,
  NewQuickTopSale,
} from "../index";

export class AdminStats extends React.Component {
  render() {
    return (
      <div className="container-fluid">
        {/* <QuickStats /> */}
        <NewQuickStats />
        <NewQuickChart />
        <NewQuickTopSale />
      </div>
    );
  }
}
