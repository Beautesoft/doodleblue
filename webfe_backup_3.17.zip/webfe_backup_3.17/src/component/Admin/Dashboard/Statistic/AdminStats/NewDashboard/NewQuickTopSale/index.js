import React, { Component } from "react";
import { TopTenList } from "./TopTenList";
import {
  NormalInput,
  NormalSelect,
  NormalButton,
  NormalDate,
  NormalModal,
} from "component/common";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import { getCommonApi } from "redux/actions/common";
import "./style.scss";

export class NewQuickTopSaleClass extends Component {
  state = {
    top_product: [],
    top_service: [],
    top_prepaid: [],
    top_voucher: [],
    top_td: [],
    toplistcount: 10,
    Top10byPrice: true,
    Top20byPrice: false,
    Top10byQty: false,
    Top20byQty: false,
    orderBy: "price",
  };
  componentWillMount() {
    this.getTopList();
  }

  getTopList = () => {
    let {
      top_product,
      top_service,
      top_prepaid,
      top_voucher,
      top_td,
      toplistcount,
      orderBy,
    } = this.state;

    this.props
      .getCommonApi(
        `dashboardtopproduct/?select=${toplistcount}&order_by=${orderBy}`
      )
      .then(res => {
        console.log(res, "custtopsalereport");
        top_product = res.top_product;
        top_service = res.top_service;
        top_prepaid = res.top_prepaid;
        top_voucher = res.top_voucher;
        top_td = res.top_td;
        this.setState({
          top_product,
          top_service,
          top_prepaid,
          top_voucher,
          top_td,
        });
      });
  };

  onChangeTop10byPrice = async () => {
    await this.setState({
      Top10byPrice: true,
      Top20byPrice: false,
      Top10byQty: false,
      Top20byQty: false,
      toplistcount: 10,
      orderBy: "price",
    });
    this.getTopList();
  };
  onChangeTop20byPrice = async () => {
    await this.setState({
      Top10byPrice: false,
      Top20byPrice: true,
      Top10byQty: false,
      Top20byQty: false,
      toplistcount: 20,
      orderBy: "price",
    });
    this.getTopList();
  };
  onChangeTop10byQty = async () => {
    await this.setState({
      Top10byPrice: false,
      Top20byPrice: false,
      Top10byQty: true,
      Top20byQty: false,
      toplistcount: 10,
      orderBy: "qty",
    });
    this.getTopList();
  };
  onChangeTop20byQty = async () => {
    await this.setState({
      Top10byPrice: false,
      Top20byPrice: false,
      Top10byQty: false,
      Top20byQty: true,
      toplistcount: 20,
      orderBy: "qty",
    });
    this.getTopList();
  };

  render() {
    let {
      top_product,
      top_service,
      top_prepaid,
      top_voucher,
      top_td,
      toplistcount,
      Top10byPrice,
      Top20byPrice,
      Top10byQty,
      Top20byQty,
    } = this.state;
    return (
      <div className="TopTen">
        <div className="d-flex justify-content-start flex-wrap mt-5 mb-1">
          <div
            className={`card col-md-2 col-2 p-1 mr-2 cursor activeColor button-shadow ${
              Top10byPrice ? "active" : ""
            }`}
            onClick={this.onChangeTop10byPrice}
          >
            <span className="text-center fs-16 fw-500">Top 10 by Price</span>
          </div>
          <div
            className={`card col-md-2 col-2 p-1 ml-2 cursor activeColor button-shadow ${
              Top20byPrice ? "active" : ""
            } `}
            onClick={this.onChangeTop20byPrice}
          >
            <p className="text-center fs-16 fw-500">Top 20 by Price</p>
          </div>
          <div
            className={`card col-md-2 col-2 p-1 ml-2 cursor activeColor button-shadow ${
              Top10byQty ? "active" : ""
            } `}
            onClick={this.onChangeTop10byQty}
          >
            <p className="text-center fs-16 fw-500">Top 10 by QTY</p>
          </div>
          <div
            className={`card col-md-2 col-2 p-1 ml-2 cursor activeColor button-shadow ${
              Top20byQty ? "active" : ""
            } `}
            onClick={this.onChangeTop20byQty}
          >
            <p className="text-center fs-16 fw-500">Top 20 by QTY</p>
          </div>
        </div>

        <div className="d-flex row flex-wrap px-2">
          <div className="col-md-4 col-12">
            <TopTenList Title="Product Sales" topTenList={top_product} />
          </div>
          <div className="col-md-4 col-12">
            <TopTenList Title="Service Sales" topTenList={top_service} />
          </div>
          <div className="col-md-4 col-12">
            <TopTenList Title="Prepaid Sales" topTenList={top_prepaid} />
          </div>
          <div className="col-md-4 col-12">
            <TopTenList Title="Voucher Sales" topTenList={top_voucher} />
          </div>
          <div className="col-md-4 col-12">
            <TopTenList Title="Treatment Done" topTenList={top_td} />
          </div>
        </div>
      </div>
    );
  }
}

const mapDispatchToProps = dispatch => {
  return bindActionCreators(
    {
      getCommonApi,
    },
    dispatch
  );
};

export const NewQuickTopSale = connect(
  null,
  mapDispatchToProps
)(NewQuickTopSaleClass);
