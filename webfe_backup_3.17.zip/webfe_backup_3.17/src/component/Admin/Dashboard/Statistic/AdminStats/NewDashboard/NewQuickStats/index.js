import React, { Component } from "react";
import "./style.scss";
import { InputSearch } from "component/common";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import { history } from "helpers";
import { getCommonApi, commonCreateApi } from "redux/actions/common";

export class NewQuickStatsClass extends Component {
  state = {
    customer: { daily_custcnt: 0, monthly_custcnt: 0, total_cust: 0 },
    product_sold: {
      dailyproduct_qty: 0,
      monthlyproduct_qty: 0,
      daily_product: "0.00",
      monthly_product: "0.00",
      daily_product_ar: "0.00",
      monthly_product_ar: "0.00",
    },
    service_sold: {
      dailyservice_qty: 0,
      monthlyservice_qty: 0,
      daily_service: "0.00",
      monthly_service: "0.00",
      daily_service_ar: "0.00",
      monthly_service_ar: "0.00",
    },
    voucher_sold: {
      dailyvoucher_qty: 0,
      monthlyvoucher_qty: 0,
      daily_voucher: "0.00",
      monthly_voucher: "0.00",
    },
    prepaid_sold: {
      dailyprepaid_qty: 0,
      monthlyprepaid_qty: 0,
      daily_prepaid: "0.00",
      monthly_prepaid: "0.00",
      daily_prepaid_ar: "0.00",
      monthly_prepaid_ar: "0.00",
    },
    treatment_done: {
      daily_tdqty: 0,
      monthly_tdqty: 0,
      daily_tdamt: "0.00",
      monthly_tdamt: "0.00",
    },
    total_collection: {
      daily_sales: "0.00",
      monthly_sales: "0.00",
      daily_nonsales: "0.00",
      monthly_nonsales: "0.00",
      total_daily: "0.00",
      total_monthly: "0.00",
    },
  };

  componentWillMount() {
    this.getCustomerProductandService();
    this.getVoucherandPrepaid();
    this.getTreatmentandTotal();
  }

  getCustomerProductandService = () => {
    let { customer, product_sold, service_sold } = this.state;
    this.props.getCommonApi(`dashboardcust/`).then(res => {
      console.log(res, "custdashbordpart");
      customer = res.customer;
      product_sold = res.product_sold;
      service_sold = res.service_sold;
      this.setState({
        customer,
        product_sold,
        service_sold,
      });
    });
  };
  getVoucherandPrepaid = () => {
    let { voucher_sold, prepaid_sold } = this.state;
    this.props.getCommonApi(`dashboardvoucher/`).then(res => {
      console.log(res, "voucherandprepaid");
      voucher_sold = res.voucher_sold;
      prepaid_sold = res.prepaid_sold;
      this.setState({
        voucher_sold,
        prepaid_sold,
      });
    });
  };
  getTreatmentandTotal = () => {
    let { treatment_done, total_collection } = this.state;
    this.props.getCommonApi(`dashboardtd/`).then(res => {
      console.log(res, "treatment and total");
      treatment_done = res.treatment_done;
      total_collection = res.total_collection;
      this.setState({
        treatment_done,
        total_collection,
      });
    });
  };
  render() {
    let {
      customer,
      product_sold,
      service_sold,
      voucher_sold,
      prepaid_sold,
      treatment_done,
      total_collection,
    } = this.state;
    return (
      <div className="quickStats">
        <div className="d-flex align-items-center mb-2">
          <h6 className="team-label w-100">
            Dashboard(Daily / <span className="text-danger">Monthly</span>)
          </h6>
        </div>
        <div className="row">
          <div className="col-md-4">
            <div className="d-flex stats-card">
              <div className="col-md-4 d-flex align-items-center mb-3">
                <i className={"icon-user-1 stats-icon"}></i>
              </div>
              <div className="card col-md-8 col-8">
                <div className="row m-0">
                  <div className="col-12 pl-0 count-label">
                    <h5>
                      <span>{customer.daily_custcnt} / </span>
                      <span className="text-danger">
                        {customer.monthly_custcnt}
                      </span>
                    </h5>
                    <p>New Customer</p>
                  </div>
                </div>
                <div className="row m-0 pt-1">
                  <div className="col-12 pl-0 count-label">
                    <h5>
                      <span>{customer.total_cust}</span>
                    </h5>
                    <p>Total Customer</p>
                  </div>
                </div>
                <div className="d-flex justify-content-center">
                  <p className="text-center fs-15 fw-500">Customers</p>
                </div>
              </div>
            </div>
          </div>
          <div className="col-md-4"></div>
          <div className="col-md-4"></div>
        </div>
        <div className="row">
          <div className="col-md-4">
            <div className="d-flex stats-card">
              <div className="col-md-4 d-flex align-items-center mb-3">
                <i className={"icon-shopping-bag stats-icon"}></i>
              </div>
              <div className="card col-md-8 col-8">
                <div className="row m-0">
                  <div className="col-12 pl-0 count-label">
                    <h5>
                      <span>{product_sold.dailyproduct_qty} / </span>
                      <span className="text-danger">
                        {product_sold.monthlyproduct_qty}
                      </span>
                    </h5>
                    <p>Qty</p>
                  </div>
                </div>
                <div className="row m-0 pt-1">
                  <div className="col-12 pl-0 count-label">
                    <h5>
                      <span>{product_sold.daily_product} / </span>
                      <span className="text-danger">
                        {product_sold.monthly_product}
                      </span>
                    </h5>
                    <p>Amount (RM)</p>
                  </div>
                </div>
                <div className="row m-0 pt-1">
                  <div className="col-12 pl-0 count-label">
                    <h5>
                      <span>{product_sold.daily_product_ar} / </span>
                      <span className="text-danger">
                        {product_sold.monthly_product_ar}
                      </span>
                    </h5>
                    <p>AR Amount (RM)</p>
                  </div>
                </div>
                <div className="d-flex justify-content-center">
                  <p className="text-center fs-15 fw-500">Product Sold</p>
                </div>
              </div>
            </div>
            <div className="d-flex stats-card">
              <div className="col-md-4 d-flex align-items-center mb-3">
                <i className={"icon-money-1-1 stats-icon"}></i>
              </div>
              <div className="card col-md-8 col-8">
                <div className="row m-0">
                  <div className="col-12 pl-0 count-label">
                    <h5>
                      <span>{service_sold.dailyservice_qty} / </span>
                      <span className="text-danger">
                        {service_sold.monthlyservice_qty}
                      </span>
                    </h5>
                    <p>Qty</p>
                  </div>
                </div>
                <div className="row m-0 pt-1">
                  <div className="col-12 pl-0 count-label">
                    <h5>
                      <span>{service_sold.daily_service} / </span>
                      <span className="text-danger">
                        {service_sold.monthly_service}
                      </span>
                    </h5>
                    <p>Amount (RM)</p>
                  </div>
                </div>
                <div className="row m-0 pt-1">
                  <div className="col-12 pl-0 count-label">
                    <h5>
                      <span>{service_sold.daily_service_ar} / </span>
                      <span className="text-danger">
                        {service_sold.monthly_service_ar}
                      </span>
                    </h5>
                    <p>AR Amount (RM)</p>
                  </div>
                </div>
                <div className="d-flex justify-content-center">
                  <p className="text-center fs-15 fw-500">Service Sold</p>
                </div>
              </div>
            </div>
          </div>

          <div className="col-md-4">
            <div className="d-flex stats-card">
              <div className="col-md-4 d-flex align-items-center mb-3">
                <i className={"icon-hospitality stats-icon"}></i>
              </div>
              <div className="card col-md-8 col-8">
                <div className="row m-0">
                  <div className="col-12 pl-0 count-label">
                    <h5>
                      <span>{voucher_sold.dailyvoucher_qty} / </span>
                      <span className="text-danger">
                        {voucher_sold.monthlyvoucher_qty}
                      </span>
                    </h5>
                    <p>Qty</p>
                  </div>
                </div>
                <div className="row m-0 pt-1">
                  <div className="col-12 pl-0 count-label">
                    <h5>
                      <span>{voucher_sold.daily_voucher} / </span>
                      <span className="text-danger">
                        {voucher_sold.monthly_voucher}
                      </span>
                    </h5>
                    <p>Amount (RM)</p>
                  </div>
                </div>
                <div className="d-flex justify-content-center">
                  <p className="text-center fs-15 fw-500">Voucher Sold</p>
                </div>
              </div>
            </div>
            <div className="d-flex stats-card">
              <div className="col-md-4 d-flex align-items-center mb-3">
                <i className={"icon-profit stats-icon"}></i>
              </div>
              <div className="card col-md-8 col-8">
                <div className="row m-0">
                  <div className="col-12 pl-0 count-label">
                    <h5>
                      <span>{prepaid_sold.dailyprepaid_qty} / </span>
                      <span className="text-danger">
                        {prepaid_sold.monthlyprepaid_qty}
                      </span>
                    </h5>
                    <p>Qty</p>
                  </div>
                </div>
                <div className="row m-0 pt-1">
                  <div className="col-12 pl-0 count-label">
                    <h5>
                      <span>{prepaid_sold.daily_prepaid} / </span>
                      <span className="text-danger">
                        {prepaid_sold.monthly_prepaid}
                      </span>
                    </h5>
                    <p>Amount (RM)</p>
                  </div>
                </div>
                <div className="row m-0 pt-1">
                  <div className="col-12 pl-0 count-label">
                    <h5>
                      <span>{prepaid_sold.daily_prepaid_ar} / </span>
                      <span className="text-danger">
                        {prepaid_sold.monthly_prepaid_ar}
                      </span>
                    </h5>
                    <p>AR Amount (RM)</p>
                  </div>
                </div>
                <div className="d-flex justify-content-center">
                  <p className="text-center fs-15 fw-500">Prepaid Sold</p>
                </div>
              </div>
            </div>
          </div>
          <div className="col-md-4">
            <div className="d-flex stats-card">
              <div className="col-md-4 d-flex align-items-center mb-3">
                <i className={"icon-hospitality stats-icon"}></i>
              </div>
              <div className="card col-md-8 col-8">
                <div className="row m-0">
                  <div className="col-12 pl-0 count-label">
                    <h5>
                      <span>{treatment_done.daily_tdqty} / </span>
                      <span className="text-danger">
                        {treatment_done.monthly_tdqty}
                      </span>
                    </h5>
                    <p>Qty</p>
                  </div>
                </div>
                <div className="row m-0 pt-1">
                  <div className="col-12 pl-0 count-label">
                    <h5>
                      <span>{treatment_done.daily_tdamt} / </span>
                      <span className="text-danger">
                        {treatment_done.monthly_tdamt}
                      </span>
                    </h5>
                    <p>Amount (RM)</p>
                  </div>
                </div>
                <div className="d-flex justify-content-center">
                  <p className="text-center fs-15 fw-500">Treatment Done</p>
                </div>
              </div>
            </div>
            <div className="d-flex stats-card">
              <div className="col-md-4 d-flex align-items-center mb-3">
                <i className={"icon-profit stats-icon"}></i>
              </div>
              <div className="card col-md-8 col-8">
                <div className="row m-0">
                  <div className="col-12 pl-0 count-label">
                    <h5>
                      <span>{total_collection.daily_sales} / </span>
                      <span className="text-danger">
                        {total_collection.monthly_sales}
                      </span>
                    </h5>
                    <p>Sales (RM)</p>
                  </div>
                </div>
                <div className="row m-0 pt-1">
                  <div className="col-12 pl-0 count-label">
                    <h5>
                      <span>{total_collection.daily_nonsales} / </span>
                      <span className="text-danger">
                        {total_collection.monthly_nonsales}
                      </span>
                    </h5>
                    <p>Non Sales (RM)</p>
                  </div>
                </div>
                <div className="row m-0 pt-1">
                  <div className="col-12 pl-0 count-label">
                    <h5>
                      <span>{total_collection.total_daily} / </span>
                      <span className="text-danger">
                        {total_collection.total_monthly}
                      </span>
                    </h5>
                    <p>Total Sales (RM)</p>
                  </div>
                </div>
                <div className="d-flex justify-content-center">
                  <p className="text-center fs-15 fw-500">Total Collection</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

const mapDispatchToProps = dispatch => {
  return bindActionCreators(
    {
      getCommonApi,
      commonCreateApi,
    },
    dispatch
  );
};

export const NewQuickStats = connect(
  null,
  mapDispatchToProps
)(NewQuickStatsClass);
