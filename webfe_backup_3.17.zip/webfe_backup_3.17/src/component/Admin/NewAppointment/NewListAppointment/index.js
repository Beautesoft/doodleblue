import React from "react";
import { Scheduler } from "./Scheduler";
import "./style.scss";
import { NormalButton, NormalInput, NormalModal } from "component/common";
import { TreatmentHistory } from "./modal/TreatmentHistory";
import { UpcomingAppointment } from "./modal/UpcomingAppointment";
import closeIcon from "assets/images/close.png";
import _ from "lodash";
import { getCustomer, getCommonApi } from "redux/actions/common";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import { Toast } from "service/toast";

export class NewListAppointmentClass extends React.Component {
  state = {
    isCalander: false,
    selectedDate: null,
    isTreatmentHistoryModal: false,
    isUpcomingAppointmentModal: false,
    customerId: 0,
    custName: "",
    isOpenModal: false,
    customerOption: [],
    search: "",
    customerNumber: 0,
  };

  handleBack = () => {
    let { isCalander } = this.state;
    isCalander = false;
    this.setState({
      isCalander,
    });
  };

  handleOpen = async date => {
    let { isCalander, selectedDate } = this.state;
    isCalander = true;
    selectedDate = date;
    await this.setState({
      selectedDate,
    });
    await this.setState({
      isCalander,
    });
  };
  handleTreatmentHistory = () => {
    let { customerId } = this.state;
    if (customerId > 0) {
      this.setState(prevState => ({
        isTreatmentHistoryModal: !prevState.isTreatmentHistoryModal,
        customerNumber: this.state.customerId,
      }));
    } else {
      Toast({ type: "error", message: "Please select customer" });
    }
  };
  handleUpcomingAppointment = () => {
    let { customerId } = this.state;
    if (customerId > 0) {
      this.setState(prevState => ({
        isUpcomingAppointmentModal: !prevState.isUpcomingAppointmentModal,
        customerNumber: this.state.customerId,
      }));
    } else {
      Toast({ type: "error", message: "Please select customer" });
    }
  };

  handleSelectCustomer = async data => {
    await this.setState({
      customerId: data.id,
      custName: data.cust_name,
      isOpenModal: false,
      customerOption: [],
    });
  };

  handleSearch = async event => {
    await this.setState({ search: event.target.value });
    if (!this.debouncedFn) {
      this.debouncedFn = _.debounce(async () => {
        let { basicApptDetail } = this.props;
        this.search(basicApptDetail);
      }, 500);
    }
    this.debouncedFn();
  };

  search = basicApptDetail => {
    let { search } = this.state;
    this.props
      .getCommonApi(
        `custappt/?Outlet=${
          basicApptDetail.branchId ? basicApptDetail.branchId : ""
        }&search=${search}`
      )
      .then(key => {
        let { status, data } = key;
        if (status === 200) {
          this.setState({ customerOption: data });
        }
      });
  };
  handleDialog = () => {
    let { isOpenModal } = this.state;
    isOpenModal = !isOpenModal;
    this.setState({
      isOpenModal,
    });
  };
  render() {
    let {
      isCalander,
      selectedDate,
      isTreatmentHistoryModal,
      isUpcomingAppointmentModal,
      customerId,
      custName,
      isOpenModal,
      customerOption,
      search,
    } = this.state;
    return (
      <>
        <div className="d-flex flex-row justify-content-end history mb-1 mt-0">
          <div className="row p-1">
            <div className="col">
              <NormalInput
                placeholder={"Select customer"}
                value={custName}
                name="customerName"
                onClick={() => this.setState({ isOpenModal: true })}
                className={`search history-search-textbox px-2 p-0`}
              />
            </div>
            <div className="col">
              <NormalButton
                buttonClass={"treatment"}
                mainbg={true}
                className="col-12 fs-15 m-0 p-0"
                label="Upcoming Appointment"
                onClick={this.handleUpcomingAppointment}
              />
            </div>
            <div className="col">
              <NormalButton
                buttonClass={"treatment"}
                mainbg={true}
                className="col-12 fs-15 "
                label="Treatment History"
                onClick={this.handleTreatmentHistory}
              />
            </div>
          </div>
        </div>
        <NormalModal
          className={"multiple-appointment select-category"}
          style={{ minWidth: "800px" }}
          modal={isOpenModal}
          handleModal={this.handleDialog}
        >
          <img
            onClick={this.handleDialog}
            className="close"
            src={closeIcon}
            alt=""
          />
          <div className="row">
            {" "}
            <h5 className="text-center">Select Customer</h5>
          </div>
          <div className="row mt-2 mb-5 mx-3">
            <div className="col-1 pl-0">Search</div>
            <div className="col-5">
              <input
                name="search"
                onChange={this.handleSearch}
                className="search m-0 p-0 px-3"
              />
            </div>
            <div className="col-3">
              <NormalButton
                buttonClass={"mx-2 p-0"}
                mainbg={true}
                className=" fs-15 confirm"
                label="Search"
                outline={false}
                onClick={() => this.search(search)}
              />
            </div>

            <div className="row mt-4 table-header w-100 m-0">
              <div className="col-2">Name</div>
              <div className="col-2">Phone</div>
              <div className="col-3">Cust Code</div>
              <div className="col-5">Email</div>
            </div>
            <div className="response-table w-100">
              {customerOption.length > 0 ? (
                customerOption.map((item, index) => {
                  return (
                    <div
                      className="row m-0 table-body w-100"
                      onClick={() => this.handleSelectCustomer(item)}
                      key={index}
                    >
                      <div className="col-2">{item.cust_name}</div>
                      <div className="col-2">{item.cust_phone1}</div>
                      <div className="col-3">{item.cust_code}</div>
                      <div className="col-5">{item.cust_email}</div>
                    </div>
                  );
                })
              ) : (
                <div className="text-center w-100">No Data are available</div>
              )}
            </div>
          </div>
        </NormalModal>
        {isTreatmentHistoryModal ? (
          <TreatmentHistory
            isTreatmentHistoryModal={isTreatmentHistoryModal}
            handleTreatmentHistory={this.handleTreatmentHistory}
            customerNumber={this.state.customerNumber}
          />
        ) : (
          ""
        )}
        {isUpcomingAppointmentModal ? (
          <UpcomingAppointment
            isUpcomingAppointmentModal={isUpcomingAppointmentModal}
            handleUpcomingAppointment={this.handleUpcomingAppointment}
            customerNumber={this.state.customerNumber}
          />
        ) : (
          ""
        )}
        <div>
          <Scheduler handleOpen={this.handleOpen} />
        </div>
      </>
    );
  }
}

const mapStateToProps = state => ({
  basicApptDetail: state.appointment.basicApptDetail,
});

const mapDispatchToProps = dispatch => {
  return bindActionCreators(
    {
      getCustomer,
      getCommonApi,
    },
    dispatch
  );
};

export const NewListAppointment = connect(
  mapStateToProps,
  mapDispatchToProps
)(NewListAppointmentClass);
