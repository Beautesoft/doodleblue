/*
Changes : 21 /12 /2020
cashSelectType - >CASH

Changes : 24 /12 /2020
UPI label changed to Old bill
*/
import React, { Component } from "react";
import {
  NormalInput,
  NormalButton,
  NormalSelect,
} from "component/common";
import { getPayment, createPayment } from "redux/actions/payment";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import { history } from "helpers";
import { getCommonApi } from "redux/actions/common";
import { dateFormat } from "service/helperFunctions";
import "./style.scss";
import SimpleReactValidator from "simple-react-validator";
const moment = require("moment");
export class MakePaymentClass extends Component {
  state = {
    formFields: {
      name: "",
      contact: "",
      address: "",
      searchStaff: "",
    },
    responseData: {},
    selectType: {
      creditOrDebit: false,
      point: false,
      ewalletSelectType: false,
      cashSelectType: false,
      customerBankSelectType:false,
      touchAndGoSelectType:false,
      oldBillSelectType: false,
      prepaidSelectType: false,
      voucherSelectType:false,
      creditNoteSelectType: false,
    },
    premisesOption: [],
    selectedCards: [],
    selectedCardsPayAmount: 0,
    cardOption: [],
    ewalletoptions: [],
    premiseField: {
      pay_typeid: null,
      pay_amt: "",
      pay_premise: true,
    },
    upiField: {
      pay_typeid: null,
      pay_amt: "",
      pay_upi: true,
    },
    ewalletField: {
      pay_typeid: null,
      pay_amt: "",
      credit_debit: true,
    },
    cardField: {
      pay_typeid: null,
      pay_amt: "",
      credit_debit: true,
      pay_rem1: "",
      pay_rem2: "",
      pay_rem3: "",
      pay_rem4: "",
    },
    balance: 0,
    txtCashAmount: 0,
    txtCustomerBankAmount:0,
    txtTouchAndGoAmount:0,
    txtOldBillAmount: 0,
    txtPrepaidAmount: 0,
    txtCreditNoteAmount: 0,
    txtVoucherAmount: 0,
    errorMessage: "123",
    prepaidCustomerData: [],
    voucherCustomerData:[],
    creditNoteCustomerData: [],
    accountHeader: [],
    isMakePaymentButtonClicked: "false",
    isTreatmentDoneButton: true,
    itemProductAmount: 0,
    itemServiceAmount: 0,
    itemProductServiceVoucherAmount: 0,
    displayTablePrepaid: [],
    displayTableCreditNote: [],
    displayTableVoucher:[],
    paytableData:[],
  };

  componentDidMount() {
    this.getPayment();
    this.getPaytableList();
    this.getPrepaidData();
    this.getCreditNoteAccountData("");
    this.getVoucherData("");
  }
  componentWillMount = () => {
    this.validator = new SimpleReactValidator({
      element: (message) => (
        <span className="error-message text-danger validNo fs14">
          {message}
        </span>
      ),
      autoForceUpdate: this,
    });
  };
  // get method for payment detail against appointment
  getPayment = () => {
    let { id, cartId, cartData } = this.props;
    if (id) {
      this.props
        .getPayment(
          `?cart_date=${dateFormat(
            new Date(),
            "yyyy-mm-dd"
          )}&cust_noid=${id}&cart_id=${cartId}`
        )
        .then((res) => {
          this.setState({
            responseData: res.data,
            balance: Number(res.data.billable_amount),
          });
        });
    } else {
      // history.push("/admin/cart");
    }

    //let {cartData} = this.props;
    let stringifiedCartData = cartData.data;
    let {
      itemProductAmount,
      itemServiceAmount,
      itemProductServiceVoucherAmount,
    } = this.state;
    if (stringifiedCartData) {
      stringifiedCartData.map((item) => {
        //alert(JSON.stringify(item));
        if (item.recorddetail === "Product") {
          itemProductAmount += parseFloat(item.total_price);
        }
        if (item.recorddetail === "Service") {
          itemServiceAmount += parseFloat(item.total_price);
        }
        if (
          item.recorddetail === "Product" ||
          item.recorddetail === "Service" ||
          item.recorddetail === "Voucher"
        ) {
          itemProductServiceVoucherAmount += parseFloat(item.total_price);
        }
      });
    }
    this.setState({
      itemProductAmount,
      itemServiceAmount,
      itemProductServiceVoucherAmount,
    });
  };
  getPrepaidData = () => {
    this.getPrepaidAccountData("");
  };

  getVoucherData = (api) => {
    this.props
      .getCommonApi(`voucher/?cust_id=${this.props.id}${api}`)
      .then((key) => {
        let { data } = key;
        let { voucherCustomerData } = this.state;
        voucherCustomerData = data;
        console.log("voucherCustomerData", data);
        // accountHeader = header_data;
        this.setState({ voucherCustomerData }, () => {
          console.log("test");
          this.HideVoucherTableData();
        });
      });
  };
  getPrepaidAccountData = (api) => {
    this.props
      .getCommonApi(`prepaidacclist/?cust_id=${this.props.id}${api}`)
      .then((key) => {
        let { data } = key;
        let { prepaidCustomerData } = this.state;
        prepaidCustomerData = data;
        console.log("prepaidCustomerData", data);
        // accountHeader = header_data;
        this.setState({ prepaidCustomerData }, () => {
          this.HidePrepaidTableData();
        });
      });
  };
  getCreditNoteAccountData = (api) => {
    this.props
      .getCommonApi(`creditnotelist/?cust_id=${this.props.id}${api}`)
      .then((key) => {
        let { data } = key;
        let { creditNoteCustomerData } = this.state;
        creditNoteCustomerData = data;
        // accountHeader = header_data;
        this.setState({ creditNoteCustomerData }, () => {
          this.HideCreditNoteTableData();
        });
      });
  };

  // get response for payment options dropdown
  getPaytableList = () => {
    this.props.getCommonApi(`paytable/`).then((res) => {
      this.getDataFromResponses(res.data);
    });
  };

  // set data to dropdown fields
  getDataFromResponses = (data) => {
    let { cardOption, premisesOption,ewalletoptions,paytableData } = this.state;
    paytableData=data;
    for (let key of data.CARD) {
      cardOption.push({ label: key.pay_description, value: key.id });
    }
    for (let key of data.CASH) {
      premisesOption.push({ label: key.pay_description, value: key.id });
    }
    for (let key of data['E-WALLET']) {
      ewalletoptions.push({ label: key.pay_description, value: key.id });
    }
    this.setState({
      cardOption,
      premisesOption,
      ewalletoptions,
      paytableData
    });
  };

  handleMultiple = ({ target: { value, name } }) => {
    console.log("handleMultiple", value, name);
    let formFields = Object.assign({}, this.state.formFields);

    formFields[name] = value;

    this.setState({
      formFields,
    });
  };

  handleChange = ({ target: { value, name } }) => {
    let formFields = Object.assign({}, this.state.formFields);

    formFields[name] = value;

    this.setState({
      formFields,
    });
  };

  handleSelectOption = async (e) => {
    let selectType = Object.assign({}, this.state.selectType);
    console.log(e.target.name, "radio_button_select", this.state);
    let {
      cardField,
      ewalletField,
      balance,
    } = this.state;
    selectType[e.target.name] = !selectType[e.target.name];
    if (e.target.name === "creditOrDebit") {
      cardField["pay_amt"] = balance;
      ewalletField["pay_amt"] = balance;
      await this.setState({
        cardField,
      });
    } else if (e.target.name === "ewalletSelectType") {
      cardField["pay_amt"] = balance;
      ewalletField["pay_amt"] = balance;
      await this.setState({
        cardField,
      });
    } else if (e.target.name === "cashSelectType") {
      this.state.txtCashAmount = balance;
    } 
    else if (e.target.name === "customerBankSelectType") {
      this.state.txtCustomerBankAmount = balance;
    } 
    else if (e.target.name === "touchAndGoSelectType") {
      this.state.txtTouchAndGoAmount = balance;
    } 
    else if (e.target.name === "oldBillSelectType") {
      this.state.txtOldBillAmount = balance;
      /* premiseField['pay_amt'] = balance
     
      await this.setState({
        premiseField
      });
      this.changedefaultPaymentForOnpremise("pay_typeid",2);*/
    } else if (e.target.name === "prepaidSelectType") {
      this.state.txtPrepaidAmount = balance;
    } else if (e.target.name === "creditNoteSelectType") {
      this.state.txtCreditNoteAmount = balance;
    }
    else if (e.target.name === "voucherSelectType") {
      this.state.txtVoucherAmount = balance;
    }
    

    this.setState({
      selectType,
    });
  };

  changedefaultPaymentForOnpremise = async (name, value) => {
    console.log("premiseFieldvalue", value);
    let premiseField = Object.assign({}, this.state.premiseField);

    premiseField[name] = value;

    await this.setState({
      premiseField,
    });
    await this.getBalance();
  };
  changedefaultPaymentForUpi = async (name, value) => {
    let upiField = Object.assign({}, this.state.upiField);

    upiField[name] = value;

    await this.setState({
      upiField,
    });
    await this.getBalance();
  };
  handleChangePremise = async ({ target: { value, name } }) => {
    console.log("premiseFieldvalue", value);
    let premiseField = Object.assign({}, this.state.premiseField);

    premiseField[name] = value;

    await this.setState({
      premiseField,
    });
    await this.getBalance();
  };

  handleChangeUpi = async ({ target: { value, name } }) => {
    console.log("upiFieldvalue", value);
    let upiField = Object.assign({}, this.state.upiField);

    upiField[name] = value;

    await this.setState({
      upiField,
    });
    await this.getBalance();
  };
  handleChangeCard = async ({ target: { value, name } }) => {
    let cardField = Object.assign({}, this.state.cardField);

    cardField[name] = value;

    await this.setState({
      cardField,
    });
    await this.getBalance();
  };

  handleChangeEWallet = async ({ target: { value, name } }) => {
    let ewalletField = Object.assign({}, this.state.ewalletField);

    ewalletField[name] = value;

    await this.setState({
      ewalletField,
    });
    await this.getBalance();
  };
  handleTreatmentDone = () => {
    let { selectedCards } = this.state;
    selectedCards.push({
      pay_typeid: 2,
      pay_amt: 0,
      credit_debit: false,
      pay_premise: true,
      prepaid: false,
    });
    let data = selectedCards;
    let { id, cartId } = this.props;
    this.props
      .createPayment(
        `?cart_date=${dateFormat(
          new Date(),
          "yyyy-mm-dd"
        )}&cust_noid=${id}&cart_id=${cartId}`,
        data
      )
      .then((res) => {
        history.push(`/admin/billing/print/bill/${res.data.sa_transacno}`);
      });
  };
  // create payment detail
  handleSubmit = () => {
    let {
      selectedCards,
    } = this.state;

    this.setState({ isMakePaymentButtonClicked: "true" });
    let data = selectedCards;
   console.log("SubmitData",data);
    let { id, cartId } = this.props;
    this.props
      .createPayment(
        `?cart_date=${dateFormat(
          new Date(),
          "yyyy-mm-dd"
        )}&cust_noid=${id}&cart_id=${cartId}`,
        data
      )
      .then((res) => {
        history.push(`/admin/billing/print/bill/${res.data.sa_transacno}`);
      });
  };

  getBalance = async () => {
    let {
      balance,
      premiseField,
      selectType,
    } = this.state;
    // await this.setState({
    //balance = responseData.billable_amount
    // })
    /* if(selectType.creditOrDebit===true){
      balance = balance - cardField.pay_amt;
    }*/
    if (selectType.cashSelectType === true) {
      balance = balance - premiseField.pay_amt;
    }

    this.setState({
      balance,
    });
  };
  checkPayTypeIdAlreadyExists(val) {
    return this.state.selectedCards.some((item) => val === item.pay_typeid);
  }
  addCreditCard = async () => {
    if (!this.validator.fieldValid("cardFieldType")) {
      this.validator.showMessageFor("cardFieldType");
      return;
    }
    if (!this.validator.fieldValid("CardAmount")) {
      this.validator.showMessageFor("CardAmount");
      return;
    }
    if (!this.validator.fieldValid("CardBalanceAmount")) {
      this.validator.showMessageFor("CardBalanceAmount");
      return;
    }
    let {
      cardField,
      ewalletField,
      selectedCards,
      balance,
      responseData,
    } = this.state;
    balance = responseData.billable_amount;
    if (parseFloat(this.state.responseData.billable_amount) > 0) {
      if (parseFloat(cardField.pay_amt) == 0) {
        return;
      }
    }
    if (this.checkPayTypeIdAlreadyExists(cardField.pay_typeid)) {
      alert(this.getTypeName(cardField.pay_typeid) + " already exists");
      return;
    } else {
      selectedCards.push({
        pay_typeid: cardField.pay_typeid,
        pay_amt: parseFloat(cardField.pay_amt),
        credit_debit: true,
        pay_premise: false,
        pay_rem1: cardField.pay_rem1,
        pay_rem2: cardField.pay_rem2,
        pay_rem3: cardField.pay_rem3,
        pay_rem4: cardField.pay_rem4,
        prepaid: false,
      });
    }

    const totalamount = selectedCards.reduce(
      (totalCardValue, card) => totalCardValue + card.pay_amt,
      0
    );

    balance = parseFloat(balance - totalamount).toFixed(2);
    cardField["pay_amt"] = balance;
    ewalletField["pay_amt"] = balance;
    this.setBalanceToAllTextBoxes(balance);
  };

  addEWallet = async () => {
    if (!this.validator.fieldValid("EWalletFieldType")) {
      this.validator.showMessageFor("EWalletFieldType");
      return;
    }
    if (!this.validator.fieldValid("EWalletAmount")) {
      this.validator.showMessageFor("EWalletAmount");
      return;
    }
    if (!this.validator.fieldValid("EWalletBalanceAmount")) {
      this.validator.showMessageFor("EWalletBalanceAmount");
      return;
    }
    let {
      cardField,
      ewalletField,
      selectedCards,
      balance,
      responseData,
    } = this.state;
    balance = responseData.billable_amount;
    if (parseFloat(this.state.responseData.billable_amount) > 0) {
      if (parseFloat(ewalletField.pay_amt) == 0) {
        return;
      }
    }
    if (this.checkPayTypeIdAlreadyExists(parseInt(ewalletField.pay_typeid))) {
      alert(this.getTypeName(ewalletField.pay_typeid) + " already exists");
      return;
    } else {
      selectedCards.push({
        pay_typeid: parseInt(ewalletField.pay_typeid),
        pay_amt: parseFloat(ewalletField.pay_amt),
        credit_debit: false,
        pay_premise: true,
        prepaid: false,
      });
    }

    const totalamount = selectedCards.reduce(
      (totalCardValue, card) => totalCardValue + card.pay_amt,
      0
    );

    balance = parseFloat(balance - totalamount).toFixed(2);
    cardField["pay_amt"] = balance;
    ewalletField["pay_amt"] = balance;
    this.setBalanceToAllTextBoxes(balance);
  };
  addButtonData = async (UIPaymentType) => {
    let fieldValidationText="";
    let payTypeId=0;
    let payAmount="";
    if(UIPaymentType=="Customer"){
       fieldValidationText="CustomerBankBalanceAmount";
       payTypeId=1074;
       payAmount=this.state.txtCustomerBankAmount;
    }
    else if(UIPaymentType=="TouchNGo"){
      fieldValidationText="TouchAndGoAmountBalanceAmount";
      payTypeId=1072;
      payAmount=this.state.txtTouchAndGoAmount;
    }
    else if(UIPaymentType=="OldBill"){
      fieldValidationText="OldBillBalanceAmount";
      payTypeId=29;
      payAmount=this.state.txtOldBillAmount;
    }
    else {
      fieldValidationText="CashBalanceAmount";
      payTypeId=2;
      payAmount=this.state.txtCashAmount;
    }
    if (!this.validator.fieldValid(fieldValidationText)) {
      this.validator.showMessageFor(fieldValidationText);
      return;
    }
    if (!this.validator.fieldValid(fieldValidationText)) {
      this.validator.showMessageFor(fieldValidationText);
      return;
    }

    let {
      cardField,
      ewalletField,
      balance,
      selectedCards
    } = this.state;

    if (parseFloat(this.state.responseData.billable_amount) > 0) {
      if (parseFloat(payAmount) == 0) {
        return;
      }
    }
    if (this.checkPayTypeIdAlreadyExists(payTypeId)) {
      alert(this.getTypeName(payTypeId) + " already exists");
      return;
    } else {
      selectedCards.push({
        pay_typeid: payTypeId,
        pay_amt: parseFloat(payAmount),
        credit_debit: false,
        pay_premise: true,
        prepaid: false,
      });
    }
    balance = parseFloat(balance - payAmount).toFixed(2);
    cardField["pay_amt"] = balance;
    ewalletField["pay_amt"] = balance;
    this.setBalanceToAllTextBoxes(balance);
  };

  addPrepaid = (selectedPrepaid) => {
    const prepaidExpDate = moment(selectedPrepaid.exp_date).format(
      "YYYY-MM-DD"
    );
    const todaysDate = moment(new Date()).format("YYYY-MM-DD");
    const isValid = moment(todaysDate).isSameOrAfter(prepaidExpDate);
    let cardPayAmount = 0;
    let {
      itemServiceAmount,
      itemProductAmount,
      itemProductServiceVoucherAmount,
      txtPrepaidAmount,
    } = this.state;
    cardPayAmount = parseFloat(txtPrepaidAmount);
    if (isValid) {
      alert("Check Expiry Date");
      return;
    }
    if (cardPayAmount <= 0) {
      // alert("hi");
      return;
    }

    const selectedRemainingPrepaidAmount = parseFloat(selectedPrepaid.remain);
    if (selectedRemainingPrepaidAmount < cardPayAmount) {
      //return
    }

    if (!this.validator.fieldValid("PrepaidBalanceAmount")) {
      this.validator.showMessageFor("PrepaidBalanceAmount");
      return;
    }
    if (!this.validator.fieldValid("PrepaidBalanceAmount")) {
      this.validator.showMessageFor("PrepaidBalanceAmount");
      return;
    }

    if (selectedPrepaid.conditiontype1 === "Service Only") {
      //For Service
      if (parseFloat(itemServiceAmount) == 0) {
        return;
      }
      if (parseFloat(itemServiceAmount) <= selectedRemainingPrepaidAmount) {
        cardPayAmount = parseFloat(txtPrepaidAmount)< parseFloat(itemServiceAmount)?parseFloat(txtPrepaidAmount):parseFloat(itemServiceAmount);
      } else {
        cardPayAmount = selectedRemainingPrepaidAmount;
      }
      itemServiceAmount=itemServiceAmount-cardPayAmount;
      this.setState({itemServiceAmount});
    } else if (selectedPrepaid.conditiontype1 === "Product Only") {
      //For Product
      if (parseFloat(itemProductAmount) == 0) {
        return;
      }
      if (parseFloat(itemProductAmount) <= selectedRemainingPrepaidAmount) {
        cardPayAmount = parseFloat(txtPrepaidAmount)< parseFloat(itemProductAmount)?parseFloat(txtPrepaidAmount):parseFloat(itemProductAmount);
      } else {
        cardPayAmount = selectedRemainingPrepaidAmount;
      }
      itemProductAmount=itemProductAmount-cardPayAmount;
      this.setState({itemProductAmount});
    } else {
      if (parseFloat(itemProductServiceVoucherAmount) == 0) {
        return;
      }
      if (
        parseFloat(itemProductServiceVoucherAmount) <=
        selectedRemainingPrepaidAmount
      ) {
        cardPayAmount = parseFloat(txtPrepaidAmount)< parseFloat(itemProductServiceVoucherAmount)?parseFloat(txtPrepaidAmount):parseFloat(itemProductServiceVoucherAmount);
      } else {
        cardPayAmount = selectedRemainingPrepaidAmount;
      }
      itemProductServiceVoucherAmount=itemProductServiceVoucherAmount-cardPayAmount;
      this.setState({itemProductServiceVoucherAmount});
    }
    if (cardPayAmount == 0) {
      return;
    }
    const payTypeId = 23;
    let { cardField, ewalletField, balance, selectedCards } = this.state;

    selectedCards.push({
      pay_typeid: payTypeId,
      prepaid: true,
      pay_amt: cardPayAmount,
      credit_debit: false,
      pay_premise: false,
      pay_rem1:
        selectedPrepaid.pp_no +
        " - " +
        selectedPrepaid.line_no +
        " - " +
        selectedPrepaid.pp_desc,
      pay_rem2: selectedPrepaid.id,
      prepaid_ct:selectedPrepaid.conditiontype1,
    });
    console.log(
      "BeforeAdd-displayTablePrepaid",
      this.state.displayTablePrepaid
    );
    let setdisplayTablePrepaid = this.state.displayTablePrepaid;
    setdisplayTablePrepaid.push(selectedPrepaid.id);
    this.setState({ displayTablePrepaid: setdisplayTablePrepaid });
    console.log("AfterAdd-displayTablePrepaid", this.state.displayTablePrepaid);
    this.HidePrepaidTableData();

    balance = parseFloat(balance - cardPayAmount).toFixed(2);
    cardField["pay_amt"] = balance;
    ewalletField["pay_amt"] = balance;
    this.setBalanceToAllTextBoxes(balance);
  };
  HidePrepaidTableData() {
    let { prepaidCustomerData, displayTablePrepaid } = this.state;
    displayTablePrepaid.map((item) => {
      var selectedPrepaid = prepaidCustomerData.filter(
        (prepaid) => prepaid.id != item
      );
      this.setState({ prepaidCustomerData: selectedPrepaid });
    });
  }
  HideCreditNoteTableData() {
    let { creditNoteCustomerData, displayTableCreditNote } = this.state;
    displayTableCreditNote.map((item) => {
      var selectedCreditNote = creditNoteCustomerData.filter(
        (creditNote) => creditNote.credit_code != item
      );
      this.setState({ creditNoteCustomerData: selectedCreditNote });
    });
  }
  HideVoucherTableData() {
    let { voucherCustomerData, displayTableVoucher } = this.state;
    displayTableVoucher.map((item) => {
      var selectedVoucher = voucherCustomerData.filter(
        (voucher) => voucher.voucher_no != item
      );
      this.setState({ voucherCustomerData: selectedVoucher });
    });
  }
  addVoucher = (selectedVoucher) => {
    let {
      cardField,
      ewalletField,
      balance,
      txtVoucherAmount,
      selectedCards,
    } = this.state;
    if(txtVoucherAmount==0){
      return;
    }
    const selectedVoucherAmount = parseFloat(selectedVoucher.value);
    let pay_amt_setup = 0;
    if (selectedVoucherAmount <= parseFloat(txtVoucherAmount)) {
      pay_amt_setup = selectedVoucherAmount;
    } else {
      alert("Partial Amount is not applicable in voucher");
      return;
    }
    const payTypeId = 9;

    selectedCards.push({
      pay_typeid: payTypeId,
      prepaid: false,
      pay_amt: parseFloat(pay_amt_setup),
      credit_debit: false,
      pay_premise: false,
      pay_rem1: selectedVoucher.voucher_no,
      pay_rem2: selectedVoucher.voucher_no,
    });
    console.log(
      "BeforeAdd-displayTableVoucher",
      this.state.displayTableVoucher
    );
    let setdisplayTableVoucher = this.state.displayTableVoucher;
    setdisplayTableVoucher.push(selectedVoucher.voucher_no);
    this.setState({ displayTableVoucher: setdisplayTableVoucher });
    console.log("AfterAdd-displayTableCreditNote", this.state.displayTableVoucher);
    this.HideVoucherTableData();

    balance = parseFloat(balance - pay_amt_setup).toFixed(2);
    cardField["pay_amt"] = balance;
    ewalletField["pay_amt"] = balance;
    this.setBalanceToAllTextBoxes(balance);
  };
  addCreditNote = (selectedCreditNote) => {
    let {
      cardField,
      ewalletField,
      balance,
      txtCreditNoteAmount,
      selectedCards,
    } = this.state;
    if(txtCreditNoteAmount==0){
      return;
    }
    const selectedCreditNoteAmount = parseFloat(selectedCreditNote.balance);
    let pay_amt_setup = 0;
    if (selectedCreditNoteAmount <= parseFloat(txtCreditNoteAmount)) {
      pay_amt_setup = selectedCreditNoteAmount;
    } else {
      pay_amt_setup = txtCreditNoteAmount;
    }
    const payTypeId = 17;

    selectedCards.push({
      pay_typeid: payTypeId,
      prepaid: false,
      pay_amt: parseFloat(pay_amt_setup),
      credit_debit: false,
      pay_premise: false,
      pay_rem1: selectedCreditNote.credit_code,
      pay_rem2: selectedCreditNote.transaction,
    });
    console.log(
      "BeforeAdd-displayTableCreditNote",
      this.state.displayTableCreditNote
    );
    let setdisplayTableCreditNote = this.state.displayTableCreditNote;
    setdisplayTableCreditNote.push(selectedCreditNote.credit_code);
    this.setState({ displayTableCreditNote: setdisplayTableCreditNote });
    console.log("AfterAdd-displayTableCreditNote", this.state.displayTableCreditNote);
    this.HideCreditNoteTableData();

    balance = parseFloat(balance - pay_amt_setup).toFixed(2);
    cardField["pay_amt"] = balance;
    ewalletField["pay_amt"] = balance;
    this.setBalanceToAllTextBoxes(balance);
  };

  setBalanceToAllTextBoxes(balance){
    this.setState({
      balance: balance,
      txtCashAmount: balance,
      txtOldBillAmount: balance,
      txtPrepaidAmount: balance,
      txtCreditNoteAmount: balance,
      txtVoucherAmount:balance,
      txtCustomerBankAmount:balance,
      txtTouchAndGoAmount:balance
    });
  }
  getTypeName(idToSearch) {
    
    if (idToSearch === 1074) {
      return "BANK IN";
    }
    if (idToSearch === 1072) {
      return "Touch N Go";
    }
    
    if (idToSearch === 2) {
      return "CASH";
    }
    if (idToSearch === 23) {
      return "Prepaid";
    }
    if (idToSearch === 17) {
      return "CreditNote";
    }
    if (idToSearch === 29) {
      return "OLDBILL";
    }
    if (idToSearch === 9) {
      return "VOUCHER";
    }
    
    const SingleEwallet = this.state.ewalletoptions.find(
      (el) => el.value == idToSearch
    );
    if (typeof(SingleEwallet) !== 'undefined' && SingleEwallet != null) {
            return SingleEwallet.label
      } else {
        const SingleCard = this.state.cardOption.find(
          (el) => el.value == idToSearch
        );
       return SingleCard.label;
}
  }
  removeCards = (idx) => () => {
    let { selectedCards, balance, cardField, ewalletField,itemProductServiceVoucherAmount,itemProductAmount,itemServiceAmount } = this.state;
    this.setState({ isMakePaymentButtonClicked: "false" });
    balance = parseFloat(balance) + parseFloat(idx.pay_amt);
    var array = [...selectedCards]; // make a separate copy of the array
    var index = array.indexOf(idx);
    if(idx.pay_typeid==23){
      if(idx.prepaid_ct=="Product Only"){
        itemProductAmount=itemProductAmount+idx.pay_amt;
      }
      else if (idx.prepaid_ct=="Service Only"){
        itemServiceAmount=itemServiceAmount+idx.pay_amt;
      }
      else
      {
        itemProductServiceVoucherAmount=itemProductServiceVoucherAmount+idx.pay_amt;
      }
      this.setState({itemProductServiceVoucherAmount,itemProductAmount,itemServiceAmount});
    }
    if (index !== -1) {
      array.splice(index, 1);
      this.setState({ selectedCards: array, balance });
    }
    //console.log("idx", idx);
    var removedTerm = idx.pay_typeid;
    //console.log("removedTerm", removedTerm);
    //console.log("idx.pay_rem2", idx.pay_rem2);
    if (removedTerm == "23") {
      const items = this.state.displayTablePrepaid;
      console.log("BeforeRemove-displayTablePrepaid", items);
      const valueToRemove = idx.pay_rem2;//For Prepaid Ony we have added unique id here
      console.log("BeforeRemove-valueToRemove", valueToRemove);
      const filteredItems = items.filter((item) => item !== valueToRemove);
      this.setState({ displayTablePrepaid: filteredItems }, () => {
        console.log(
          "AfterRemove-displayTablePrepaid",
          this.state.displayTablePrepaid
        );
      });
      this.getPrepaidAccountData("");
      // this.HidePrepaidTableData();
    }
    if (removedTerm == "17") {
      const items = this.state.displayTableCreditNote;
      console.log("BeforeRemove-displayTableCreditNote", items);
      const valueToRemove = idx.pay_rem1;//For Credit Note Ony we have added unique id here
      console.log("BeforeRemove-valueToRemove", valueToRemove);
      const filteredItems = items.filter((item) => item !== valueToRemove);
      this.setState({ displayTableCreditNote: filteredItems }, () => {
        console.log(
          "AfterRemove-displayTableCreditNote",
          this.state.displayTableCreditNote
        );
      });
      this.getCreditNoteAccountData("");
      // this.HidePrepaidTableData();
    }

    if (removedTerm == "9") {
      const items = this.state.displayTableVoucher;
      console.log("BeforeRemove-displayTableVoucher", items);
      const valueToRemove = idx.pay_rem1;//For Credit Note Ony we have added unique id here
      console.log("BeforeRemove-valueToRemove", valueToRemove);
      const filteredItems = items.filter((item) => item !== valueToRemove);
      this.setState({ displayTableVoucher: filteredItems }, () => {
        console.log(
          "AfterRemove-displayTableVoucher",
          this.state.displayTableVoucher
        );
      });
      this.getVoucherData("");
    }
    cardField["pay_amt"] = balance;
    ewalletField["pay_amt"] = balance;
    this.setBalanceToAllTextBoxes(balance);
  };
  checkTypeOfCartItemContainsDeposit(cartData) {
    let stringifiedCartData = cartData.data;
    if (stringifiedCartData) {
      stringifiedCartData.map((item) => {
        if (item.type === "Deposit" || item.type === "Top Up") {
          this.state.isTreatmentDoneButton = false;
        }
      });
    }
  }

  render() {
    let {
      formFields,
      responseData,
      selectType,
      cardOption,
      ewalletoptions,
      cardField,
      ewalletField,
      balance,
      isTreatmentDoneButton,
    } = this.state;
    let {
      creditOrDebit,
      ewalletSelectType,
      cashSelectType,
      customerBankSelectType,
      touchAndGoSelectType,
      oldBillSelectType,
      prepaidSelectType,
      creditNoteSelectType,
      voucherSelectType,
    } = selectType;
    let { cartData,tokenDetails} = this.props;
    this.checkTypeOfCartItemContainsDeposit(cartData);
    return (
      <>
        <div className="make-payment-section mb-4">
          <div className="row pl-3">
            <div className="col-10 mb-4">
              <h4>Select Payment Method</h4>
            </div>

            {/* <div className="text-right f-600">Balance: {Number(balance).toFixed(2)}</div> */}
            <div className="row">
              <div className="col-8 fs-14 p-5 payment">
                <div className="row">
               
                <div className="col-10">
                  
                    <div class="radio-item">
                      <input
                        type="radio"
                        id="creditOrDebit"
                        name="creditOrDebit"
                        checked={creditOrDebit}
                        onClick={this.handleSelectOption}
                      />
                      <label for="creditOrDebit">Credit / Debit card</label>
                    </div>
                    {creditOrDebit ? (
                      <>
                        <div className="row mt-3 credit-card">
                          <div className="col-5">
                            <div className="input-group">
                              Select Card
                              <NormalSelect
                                placeholder="Search type..."
                                options={cardOption}
                                value={cardField.pay_typeid}
                                name="pay_typeid"
                                onChange={this.handleChangeCard}
                              />
                            </div>
                            {this.validator.message(
                              "cardFieldType",
                              cardField.pay_typeid,
                              "required"
                            )}
                          </div>
                          <div className="col-3">
                            <div className="input-group">
                              Amount
                              <NormalInput
                                value={cardField.pay_amt}
                                name="pay_amt"
                                onChange={this.handleChangeCard}
                              />
                            </div>

                            {this.validator.message(
                              "CardAmount",
                              cardField.pay_amt,
                              "required|numeric|min:0,num"
                            )}
                            {this.validator.message(
                              "CardBalanceAmount",
                              cardField.pay_amt,
                              "required|numeric|max:" +
                                this.state.balance +
                                ",num"
                            )}
                          </div>
                          <div className="col-4">
                            <div className="input-group">
                            {!isTreatmentDoneButton ? (
                              <NormalButton
                                mainbg={true}
                                className="col-12 fs-15 "
                                label="ADD "
                                onClick={() => this.addCreditCard()}
                              />
                              ) : null}
                            </div>
                          </div>
                          <div className="col-5">
                            <div className="input-group">
                              Card No
                              <NormalInput
                                value={cardField.pay_rem1}
                                name="pay_rem1"
                                onChange={this.handleChangeCard}
                              />
                            </div>
                          </div>
                          <div className="col-5">
                            <div className="input-group">
                              Name
                              <NormalInput
                                value={cardField.pay_rem2}
                                name="pay_rem2"
                                onChange={this.handleChangeCard}
                              />
                            </div>
                          </div>
                          <div className="col-5">
                            <div className="input-group">
                              Exp Month
                              <NormalInput
                                value={cardField.pay_rem3}
                                name="pay_rem3"
                                onChange={this.handleChangeCard}
                              />
                            </div>
                          </div>
                          <div className="col-5">
                            <div className="input-group">
                              Exp Year
                              <NormalInput
                                value={cardField.pay_rem4}
                                name="pay_rem4"
                                onChange={this.handleChangeCard}
                              />
                            </div>
                          </div>
                        </div>
                      </>
                    ) : (
                      ""
                    )}
                  </div>
                  {this.state.ewalletoptions.length>=1 ?
                  <div className="col-10">
                    <div class="radio-item">
                      <input
                        type="radio"
                        id="ewalletSelectType"
                        name="ewalletSelectType"
                        checked={ewalletSelectType}
                        onClick={this.handleSelectOption}
                      />
                      <label for="ewalletSelectType">E-Wallet</label>
                    </div>
                    {ewalletSelectType ? (
                      <>
                        <div className="row mt-3 credit-card">
                          <div className="col-5">
                            <div className="input-group">
                              Select Wallet
                              <NormalSelect
                                placeholder="Search type..."
                                options={ewalletoptions}
                                value={ewalletField.pay_typeid}
                                name="pay_typeid"
                                onChange={this.handleChangeEWallet}
                              />
                            </div>
                            {this.validator.message(
                              "EWalletFieldType",
                              ewalletField.pay_typeid,
                              "required"
                            )}
                          </div>
                          <div className="col-3">
                            <div className="input-group">
                              Amount
                              <NormalInput
                                value={ewalletField.pay_amt}
                                name="pay_amt"
                                onChange={this.handleChangeEWallet}
                              />
                            </div>

                            {this.validator.message(
                              "EWalletAmount",
                              ewalletField.pay_amt,
                              "required|numeric|min:0,num"
                            )}
                            {this.validator.message(
                              "EWalletBalanceAmount",
                              ewalletField.pay_amt,
                              "required|numeric|max:" +
                                this.state.balance +
                                ",num"
                            )}
                          </div>
                          <div className="col-4">
                            <div className="input-group">
                            {!isTreatmentDoneButton ? (
                              <NormalButton
                                mainbg={true}
                                className="col-12 fs-15 "
                                label="ADD"
                                onClick={() => this.addEWallet()}
                              />
                            ):null}
                            </div>
                          </div>
                        </div>
                      </>
                    ) : (
                      ""
                    )}
                  </div>
                  :"" }
                  <div className="col-md-12">
                    <div class="radio-item">
                      <input
                        type="radio"
                        id="cashSelectType"
                        name="cashSelectType"
                        checked={cashSelectType}
                        onClick={this.handleSelectOption}
                      />
                      <label for="cashSelectType">Cash</label>
                    </div>
                    {cashSelectType ? (
                      <>
                        <div className="row mt-3">
                          <div className="col-3">
                            <NormalInput
                              value={this.state.txtCashAmount}
                              onChange={(e) =>
                                this.setState({
                                  txtCashAmount: e.target.value,
                                })
                              }
                            />
                          </div>

                          <div className="col-2">
                          {!isTreatmentDoneButton ? (
                            <NormalButton
                              mainbg={true}
                              className="col-12 fs-15 "
                              label="ADD"
                              onClick={() => this.addButtonData("Cash")}
                            />
                          ):null}
                          </div>
                        </div>
                        {this.validator.message(
                          "CashBalanceAmount",
                          this.state.txtCashAmount,
                          "required|numeric|min:0,num"
                        )}
                        {this.validator.message(
                          "CashBalanceAmount",
                          this.state.txtCashAmount,
                          "required|numeric|max:" + this.state.balance + ",num"
                        )}
                      </>
                    ) : (
                      ""
                    )}
                  </div>
                  
                  
                  
                  <div className="col-md-12">
                    <div class="radio-item">
                      <input
                        type="radio"
                        id="customerBankSelectType"
                        name="customerBankSelectType"
                        checked={customerBankSelectType}
                        onClick={this.handleSelectOption}
                      />
                      <label for="customerBankSelectType">CustomerBank</label>
                    </div>
                    {customerBankSelectType ? (
                      <>
                        <div className="row mt-3">
                          <div className="col-3">
                            <NormalInput
                              value={this.state.txtCustomerBankAmount}
                              onChange={(e) =>
                                this.setState({
                                  txtCustomerBankAmount: e.target.value,
                                })
                              }
                            />
                          </div>

                          <div className="col-2">
                          {!isTreatmentDoneButton ? (
                            <NormalButton
                              mainbg={true}
                              className="col-12 fs-15 "
                              label="ADD"
                              onClick={() => this.addButtonData("Customer")}
                            />
                          ):null}
                          </div>
                        </div>
                        {this.validator.message(
                          "CustomerBankBalanceAmount",
                          this.state.txtCustomerBankAmount,
                          "required|numeric|min:0,num"
                        )}
                        {this.validator.message(
                          "CustomerBankBalanceAmount",
                          this.state.txtCustomerBankAmount,
                          "required|numeric|max:" + this.state.balance + ",num"
                        )}
                      </>
                    ) : (
                      ""
                    )}
                  </div>

                  <div className="col-md-12">
                    <div class="radio-item">
                      <input
                        type="radio"
                        id="touchAndGoSelectType"
                        name="touchAndGoSelectType"
                        checked={touchAndGoSelectType}
                        onClick={this.handleSelectOption}
                      />
                      <label for="touchAndGoSelectType">Touch N Go</label>
                    </div>
                    {touchAndGoSelectType ? (
                      <>
                        <div className="row mt-3">
                          <div className="col-3">
                            <NormalInput
                              value={this.state.txtTouchAndGoAmount}
                              onChange={(e) =>
                                this.setState({
                                  txtTouchAndGoAmount: e.target.value,
                                })
                              }
                            />
                          </div>

                          <div className="col-2">
                          {!isTreatmentDoneButton ? (
                            <NormalButton
                              mainbg={true}
                              className="col-12 fs-15 "
                              label="ADD"
                              onClick={() => this.addButtonData("TouchNGo")}
                            />
                          ):null}
                          </div>
                        </div>
                        {this.validator.message(
                          "TouchAndGoAmountBalanceAmount",
                          this.state.txtTouchAndGoAmount,
                          "required|numeric|min:0,num"
                        )}
                        {this.validator.message(
                          "TouchAndGoAmountBalanceAmount",
                          this.state.txtTouchAndGoAmount,
                          "required|numeric|max:" + this.state.balance + ",num"
                        )}
                      </>
                    ) : (
                      ""
                    )}
                  </div>

                  <div className="col-md-12">
                    <div class="radio-item">
                      <input
                        type="radio"
                        id="oldBillSelectType"
                        name="oldBillSelectType"
                        checked={oldBillSelectType}
                        onClick={this.handleSelectOption}
                      />
                      <label for="oldBillSelectType">OldBill</label>
                    </div>
                    {oldBillSelectType ? (
                      <>
                        <div className="row mt-3">
                          <div className="col-3">
                            <NormalInput
                              value={this.state.txtOldBillAmount}
                              onChange={(e) =>
                                this.setState({
                                  txtOldBillAmount: e.target.value,
                                })
                              }
                            />
                          </div>

                          <div className="col-2">
                          {!isTreatmentDoneButton ? (
                            <NormalButton
                              mainbg={true}
                              className="col-12 fs-15 "
                              label="ADD"
                              onClick={() => this.addButtonData("OldBill")}
                            />
                          ):null}
                          </div>
                        </div>
                        {this.validator.message(
                          "OldBillBalanceAmount",
                          this.state.txtOldBillAmount,
                          "required|numeric|min:0,num"
                        )}
                        {this.validator.message(
                          "OldBillBalanceAmount",
                          this.state.txtOldBillAmount,
                          "required|numeric|max:" + this.state.balance + ",num"
                        )}
                      </>
                    ) : (
                      ""
                    )}
                  </div>

                  <div className="col-md-12">
                    <div class="radio-item">
                      <input
                        type="radio"
                        id="prepaidSelectType"
                        name="prepaidSelectType"
                        checked={prepaidSelectType}
                        onClick={this.handleSelectOption}
                      />
                      <label for="prepaidSelectType">Prepaid</label>
                    </div>
                    {prepaidSelectType ? (
                      <>
                        <div className="col-10">
                          <NormalInput
                            value={this.state.txtPrepaidAmount}
                            onChange={(e) =>
                              this.setState({
                                txtPrepaidAmount: e.target.value,
                              })
                            }
                          />
                          {this.validator.message(
                            "PrepaidBalanceAmount",
                            this.state.txtPrepaidAmount,
                            "required|numeric|min:0,num"
                          )}
                          {this.validator.message(
                            "PrepaidBalanceAmount",
                            this.state.txtPrepaidAmount,
                            "required|numeric|max:" +
                              this.state.balance +
                              ",num"
                          )}

                          <br />
                          <table className="table table-striped">
                            <tr>
                              <td>Category</td>
                              <td>Amount</td>
                              <td>Remaining</td>
                              <td>InvoiceNo</td>
                              <td>ExpDate</td>
                              <td>ConditionType</td>
                            </tr>
                            {this.state.prepaidCustomerData.map(
                              (selectedPrepaid, index) => (
                                <tr
                                  key={index}
                                  style={{ cursor: "pointer" }}
                                  onClick={this.addPrepaid.bind(
                                    this,
                                    selectedPrepaid
                                  )}
                                >
                                  <td>{selectedPrepaid.pp_desc}</td>
                                  <td>{selectedPrepaid.pp_total}</td>
                                  <td>{selectedPrepaid.remain}</td>
                                  <td>{selectedPrepaid.prepaid}</td>
                                  <td>{selectedPrepaid.exp_date}</td>
                                  <td>{selectedPrepaid.conditiontype1}</td>
                                </tr>
                              )
                            )}
                          </table>
                        </div>
                      </>
                    ) : (
                      ""
                    )}
                  </div>

                  <div className="col-md-12">
                    <div class="radio-item">
                      <input
                        type="radio"
                        id="voucherSelectType"
                        name="voucherSelectType"
                        checked={voucherSelectType}
                        onClick={this.handleSelectOption}
                      />
                      <label for="voucherSelectType">Voucher</label>
                    </div>
                    {voucherSelectType ? (
                      <>
                        <div className="col-10">
                          <NormalInput
                            value={this.state.txtVoucherAmount}
                            onChange={(e) =>
                              this.setState({
                                txtVoucherAmount: e.target.value,
                              })
                            }
                          />
                          {this.validator.message(
                            "VoucherBalanceAmount",
                            this.state.txtVoucherAmount,
                            "required|numeric|min:0,num"
                          )}
                          {this.validator.message(
                            "VoucherBalanceAmount",
                            this.state.txtVoucherAmount,
                            "required|numeric|max:" +
                              this.state.balance +
                              ",num"
                          )}

                          <br />
                          <table className="table table-striped">
                            <tr>
                              <td>Vocucher No</td>
                              <td>Value</td>
                              <td>Exp.Date</td>
                            </tr>
                            {this.state.voucherCustomerData.map(
                              (selectedVoucher, index) => (
                                <tr
                                  key={index}
                                  style={{ cursor: "pointer" }}
                                  onClick={this.addVoucher.bind(
                                    this,
                                    selectedVoucher
                                  )}>
                                  <td>{selectedVoucher.voucher_no}</td>
                                  <td>{selectedVoucher.value}</td>
                                  <td>{selectedVoucher.issued_expiry_date}</td>
                                </tr>
                              )
                            )}
                          </table>
                        </div>
                      </>
                    ) : (
                      ""
                    )}
                  </div>

                  <div className="col-md-12">
                    <div class="radio-item">
                      <input
                        type="radio"
                        id="creditNoteSelectType"
                        name="creditNoteSelectType"
                        checked={creditNoteSelectType}
                        onClick={this.handleSelectOption}
                      />
                      <label for="creditNoteSelectType">CreditNote</label>
                    </div>
                    {creditNoteSelectType ? (
                      <>
                        <div className="col-10">
                          <NormalInput
                            value={this.state.txtCreditNoteAmount}
                            onChange={(e) =>
                              this.setState({
                                txtCreditNoteAmount: e.target.value,
                              })
                            }
                          />
                          {this.validator.message(
                            "CreditNoteBalanceAmount",
                            this.state.txtCreditNoteAmount,
                            "required|numeric|min:0,num"
                          )}
                          {this.validator.message(
                            "CreditNoteBalanceAmount",
                            this.state.txtCreditNoteAmount,
                            "required|numeric|max:" +
                              this.state.balance +
                              ",num"
                          )}

                          <br />
                          <table className="table table-striped">
                            <tr>
                              <td>Credit #</td>
                              <td>Date</td>
                              <td>Amount</td>
                              <td>Balance</td>
                              <td>Status</td>
                            </tr>
                            {this.state.creditNoteCustomerData.map(
                              (creditNote, index) => (
                                <tr
                                  key={index}
                                  style={{ cursor: "pointer" }}
                                  onClick={this.addCreditNote.bind(
                                    this,
                                    creditNote
                                  )}
                                >
                                  <td>{creditNote.credit_code}</td>
                                  <td>{creditNote.sa_date}</td>
                                  <td>{creditNote.amount}</td>
                                  <td>{creditNote.balance}</td>
                                  <td>{creditNote.status}</td>
                                </tr>
                              )
                            )}
                          </table>
                        </div>
                      </>
                    ) : (
                      ""
                    )}
                  </div>

                  {/* <div className="col-5">
                            <h4 className="mb-4">Add Discount/Vouchers</h4>
                            <div className="input-group">
                                <NormalInput
                                    value={address}
                                    name="address"
                                    onChange={this.handleChange}
                                />
                            </div>
                        </div> */}

                  {/* <div className="col-5">
                            <h4>Enter Staff Details</h4>
                            <div className="pb-4">
                                <label className="text-left text-black common-label-text fs-17 ">
                                </label>
                                <div className="input-group">
                                    <NormalSelect
                                        placeholder="Search Staff..."
                                        // options={treatmentOption}
                                        value={searchStaff}
                                        name="searchStaff"
                                        onChange={this.handleChange}
                                    />
                                </div>
                            </div>
                            <button>Add Another Staff</button>

                        </div> */}
                        
                </div>

                
                
              </div>
             
              <div className="col-4 ">
                <div className="p-5 ml-2 subtotal">
                  <p>List of selection's</p>

                  <div className="row fs-14">
                    <div className="col-7">Subtotal</div>
                    <div className="col-5">{tokenDetails.currency} {responseData.subtotal}</div>
                    <div className="col-7">Discount ({tokenDetails.currency})</div>
                    <div className="col-5">{tokenDetails.currency} {responseData.discount}</div>
                    <div className="col-7">Transac amount</div>
                    <div className="col-5">{tokenDetails.currency} {responseData.trans_amt}</div>
                    <div className="col-7">Deposit</div>
                    <div className="col-5">{tokenDetails.currency} {responseData.deposit_amt}</div>
                    <div className="col-7">{responseData.tax_lable}</div>
                    <div className="col-5">{tokenDetails.currency} {responseData.tax_amt}</div>
                    <div className="col-12 fs-22 text-center mt-5">
                      Billing Amount
                    </div>
                    <div className="col-12 fs-22 f-700 text-center text-orenge">
                    {tokenDetails.currency} {responseData.billable_amount}
                    </div>
                    <div className="col-12 f-600 text-center mt-5">
                      Balance Amount: {Number(balance).toFixed(2)}
                    </div>
                  </div>
                </div>
              </div>
            </div>
        
            <div className="col-10">
              <br />
              <table className="table table-striped">
                {this.state.selectedCards.map((selectedCards, index) => (
                  <tr key={index}>
                    <td>{this.getTypeName(selectedCards.pay_typeid)}</td>
                    <td style={{ textAlign: "right" }}>
                      {selectedCards.pay_amt.toFixed(2)}
                    </td>
                    <td>
                      <button onClick={this.removeCards(selectedCards)}>
                        Delete
                      </button>
                    </td>
                  </tr>
                ))}
              </table>
            </div>
          </div>
          {isTreatmentDoneButton ? (
            <div className="make-payment mt-3 text-center">
              <NormalButton
                mainbg={true}
                className="col-12 fs-15 "
                label="TREATMENT DONE"
                onClick={() => this.handleTreatmentDone()}
              />
            </div>
          ) : null}
          <div className="make-payment mt-3 text-center">
            {this.state.isMakePaymentButtonClicked == "true" ? (
              <NormalButton
                mainbg={true}
                className="col-12 fs-15 "
                label="Make payment"
                disabled={true}
              />
            ) : (
              <NormalButton
                mainbg={true}
                className="col-12 fs-15 "
                label="Make payment "
                onClick={() => this.handleSubmit()}
                disabled={this.state.selectedCards.length <= 0 || balance > 0}
              />
            )}
          </div>
        </div>
      </>
    );
  }
}

const mapStateToProps = (state) => ({
  appointmentDetail: state.appointment.appointmentDetail,
  selected_cstomer: state.common.selected_cstomer,
  tokenDetails: state.authStore.tokenDetails,
});

const mapDispatchToProps = (dispatch) => {
  return bindActionCreators(
    {
      getPayment,
      getCommonApi,
      createPayment,
    },
    dispatch
  );
};

export const Payment = connect(
  mapStateToProps,
  mapDispatchToProps
)(MakePaymentClass);
