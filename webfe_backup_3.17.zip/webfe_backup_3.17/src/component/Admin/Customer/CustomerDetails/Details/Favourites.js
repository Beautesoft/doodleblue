import React, { Component } from 'react';
export class Favourites extends Component {
    render() {
        return (
            <>
            </>
        );
    }
}