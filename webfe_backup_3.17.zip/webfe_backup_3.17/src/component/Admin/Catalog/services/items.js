import React, { Component } from 'react'
import { NormalButton, NormalSelect, NormalModal } from 'component/common';
import { InputSearch, TableWrapper, Pagination } from 'component/common';
import _ from 'lodash';
import Brush from 'assets/images/make-up-brush.png'
import filter from "assets/images/filter.png";
import CartImg from "assets/images/shopping-cart.png";
import { connect } from 'react-redux';
import { bindActionCreators } from "redux";
import { getCommonApi, updateForm } from 'redux/actions/common';
import { ItemDetail } from './itemsDetail';
import closeIcon from 'assets/images/close.png';
import { history } from 'helpers'; 

export class ServicesItemClass extends Component {
    state = {
        productCard: [],
        page: 1,
        formFields: {
            search: ""
        },
        isOpenEditDetail: false,
        selectedId: "",
        list: [],
        isOpenPriceModal: false,
        serviceDetail: "",
        serviceName: ""
    }

    componentDidMount = () => {
        let { productCard } = this.state;
       this.getServices({});
       console.log(this.props, "sfdgsdfg  mount")
    }

    getServices = async(query) => {
        let { page = this.state.page, search = this.state.formFields.search } = query;
        let { rangeId="", id } = this.props;
        await this.setState({ productCard: [] })

        if(this.props.id==="Favorites"){
            await this.props.getCommonApi(`${this.props.api}/?page=${page}&search=${this.props.search}`).then((key) => {
                // await this.props.getCommonApi(`${this.props.api}/?page=${page}&search=${this.props.search}`).then((key) => {
                let { status, data } = key;
                console.log(key, "sfdgsdfg  8888888")
                if (status === 200) {
    
                    this.setState({ productCard: data, list: data.dataList })
                }
            })
        } else if(this.props.id){
            await this.props.getCommonApi(`${this.props.api}/?Item_Deptid=${this.props.menuId}&page=${page}&Item_Rangeid=${rangeId}`).then((key) => {
                let { status, data } = key;
                console.log(key, "sfdgsdfg  idddddddd")
                if (status === 200) {
    
                    this.setState({ productCard: data, list: data.dataList })
                }
            })
        } else {
            await this.props.getCommonApi(`${this.props.api}/?Item_Deptid=${this.props.menuId}&page=${page}&Item_Rangeid=${rangeId}`).then((key) => {
                let { status, data } = key;
                console.log(key, "sfdgsdfg elseeeeeee")
                if (status === 200) {
                    
                    this.setState({ productCard: data, list: data.dataList  })
                }
            })
        }

    }

    componentWillUpdate(prevProps, prevState) {
        console.log(prevProps, this.props, "sgahsdfjhagsdkjfgsadf")
        if(prevProps.search!==this.props.search){
            this.getServices({});
        }
    }

    // componentWillUnmount() {
    //     this.props.onRef(null);
    // }

    handlePagination = async (page) => {
        console.log(page)
        await this.setState({ page: page })
        this.getServices({ page: page })
    }

    handleSearch = async (event) => {
        event.persist();
        let { formFields, activeMenu } = this.state;
        formFields['search'] = event.target.value;
        activeMenu = 8;
        await this.setState({ formFields, activeMenu })
        if (!this.debouncedFn) {
            this.debouncedFn = _.debounce(() => {
                let searchString = event.target.value;
                let data = { search: searchString }
                this.getServices(data)
            }, 500);
        }
        this.debouncedFn();
    }

    handleOpenDetail = async(data) => {
        let { selectedId } = this.state;
        selectedId = data.id;
        await this.setState({ selectedId })
        this.setState({isOpenEditDetail:true})
    }

    handleDialog = () => {
        let { isOpenEditDetail, selectedId, isOpenPriceModal } = this.state;
        isOpenEditDetail = false;
        selectedId = "";
        isOpenPriceModal = "";
        this.setState({
            isOpenEditDetail,
            selectedId,
            isOpenPriceModal
        })
    }

    handleAddCart = async(data) => {
        let obj = data;
        obj["selected_menu"] = this.props.id;
        await this.props.updateForm('selectedCart', obj)
        // setTimeout(() => {
            history.push("/admin/cart");
        // }, 5000); 
    }

     handleSelectPrice = (data, index) => {
        this.setState({ isOpenPriceModal: true, serviceName: data.item_desc, serviceDetail: data })
        // history.push(`/admin/payment/${id}`)
    }

    render() {
        let { productCard={}, isOpenEditDetail, selectedId, list, isOpenPriceModal, serviceName, serviceDetail } = this.state;
        let { dataList=[], meta={} } = productCard;
        let { pagination } = meta
        console.log(this.state, "fwfyhfgd , sfdgsdfg")
        return (
            <>
                <div className="catalog-services">
                    <div className="d-flex justify-content-between align-items-center">
                        {/* <div className="">
                            <InputSearch
                                className=""
                                placeholder='Search here..'
                                onChange={this.handleSearch} />
                        </div> */}
                        {/* <div className="d-flex align-items-center nav-icon">
                            <div className="mr-3"><i className="icon-barcode"></i></div>
                            <div className="p-0 filter-icon"><img src={filter} alt="" /></div>
                        </div> */}
                    </div>
                    <div className="d-flex list flex-wrap justify-content position-relative">
                        {list.length > 0 && list.map((data, index) => (
                            <div className={`product-card card `} key={index}>
                                {/* <div className={`product-card card ${!data.stock ? 'stock-nill' : ''}`} key={index}> */}
                                <div className="d-flex justify-content-between px-3 card-title">
                                    <p className="label">{data.item_desc}</p>
                                    <div className="cart-img">
                                        <img src={CartImg} alt="" onClick={()=>this.handleAddCart(data)}/>
                                    </div>
                                </div>
                                {console.log("sadfadfasdf", this.props)}
                                {this.props.id==="RETAIL" ? <p onClick={()=>this.handleSelectPrice(data, index)} className="cost px-3"> 
                                Select</p>:<p className="cost px-3">{localStorage.getItem("Currency")}{data.item_price}</p>}
                                
                                <div className="product-img px-1">
                                    <img src={data.Stock_PIC} alt="" />
                                </div>
                                <div>
                                    <NormalButton
                                        className="col-12 fs-15 "
                                        label={"View Detail"}
                                        outline={true}
                                        onClick={()=>this.handleOpenDetail(data)}
                                    />
                                </div>
                            </div>
                        ))}
                        {pagination && <Pagination handlePagination={this.handlePagination} pageMeta={pagination} />}
                    </div>
                </div>
                <NormalModal className={"multiple-appointment"} style={{ minWidth: "760px" }} modal={isOpenEditDetail} handleModal={this.handleDialog}>
                    <img onClick={this.handleDialog} className="close" src={closeIcon} alt="" />
                    {/* <Discount discountFields={()=>{}} handleChange={()=>{}} handleSubmit={()=>{}}></Discount> */}
                    <p className="title fs-18">Detail</p>
                    <ItemDetail id={selectedId} menuId={this.props.menuId} api={this.props.api}></ItemDetail>
                </NormalModal>
                <NormalModal className={"retail-price-modal"} style={{ minWidth: "760px" }} modal={isOpenPriceModal} handleModal={this.handleDialog}>
                    <img onClick={this.handleDialog} className="close" src={closeIcon} alt="" />

                    <div className=" mt-2 mb-5 mx-3">
                        <div className="col-12 pl-0 mb-3 fs-18 py-2">
                            Select Customer
                        </div>
                        <div className="row title fs-16 mb-2 f-600">
                            <div className="col-1">S.No</div>
                            <div className="col-4">Type</div>
                            <div className="col-4">Price</div>
                            <div className="col-2">Action</div>
                        </div>
                        {serviceDetail && serviceDetail.uomprice.length > 0 ? serviceDetail.uomprice.map((data, index) => {

                            return (
                                <div className="row mb-1 fs-14">
                                    <div className="col-1">{index + 1}</div>
                                    <div className="col-4">{data.itemuom_desc}</div>
                                    <div className="col-4">{data.item_price}</div>
                                    <div className="col-2">
                                        <NormalButton
                                            buttonClass={"detail-button addtocart"}
                                            mainbg={true}
                                            className="col-12 fs-15 "
                                            label="Select"
                                            onClick={() => this.handleAddCart(serviceDetail, data.item_price, data.itemuom_id)}
                                        />
                                    </div>
                                </div>
                            )
                        }) : ""}

                    </div>
                </NormalModal>
            </>
        );
    }
}

const mapStateToProps = (state) => ({
    customerDetail: state.appointment.customerDetail,
})

const mapDispatchToProps = dispatch => {
    return bindActionCreators({
        // getCustomer,
        getCommonApi,
        updateForm
    }, dispatch)
}

export const ServicesItem = connect(mapStateToProps, mapDispatchToProps)(ServicesItemClass)