import React, { Component } from 'react';
export class PurchaseHistory extends Component {
    render() {
        return (
             <>
             </>
        );
    }
}