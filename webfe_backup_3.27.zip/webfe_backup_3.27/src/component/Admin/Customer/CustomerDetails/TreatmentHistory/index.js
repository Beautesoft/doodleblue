export { TreatmentCourse } from './treatmentCourse';
export { Diagnosis } from './diagnosis';
export { treatmentHistory } from './treatmentHistory';
export { TreatmentCourseDetails } from './treatmentCourseDetails';