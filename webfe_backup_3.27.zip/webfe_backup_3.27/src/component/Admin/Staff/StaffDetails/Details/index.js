export {Details} from './details'
export {CustomerList} from './customerList'
export { DashboardDetails } from './dashboard';
export { PerformanceDetails } from './performance'