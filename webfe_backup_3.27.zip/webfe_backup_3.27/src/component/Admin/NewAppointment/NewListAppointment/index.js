import React from "react";
import { Scheduler } from "./Scheduler";
import "./style.scss";
import { NormalButton, NormalInput, NormalModal } from "component/common";
import { TreatmentHistory } from "./modal/TreatmentHistory";
import { UpcomingAppointment } from "./modal/UpcomingAppointment";
import closeIcon from "assets/images/close.png";
import _ from "lodash";
import { getCustomer, getCommonApi } from "redux/actions/common";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import { Toast } from "service/toast";

export class NewListAppointmentClass extends React.Component {
  state = {
    isCalander: false,
    selectedDate: null,
    isTreatmentHistoryModal: false,
    isUpcomingAppointmentModal: false,
    customerId: 0,
    custName: "",
    custPhone: "",
    isOpenModal: false,
    customerOption: [],
    search: "",
    customerNumber: 0,
  };

  handleBack = () => {
    let { isCalander } = this.state;
    isCalander = false;
    this.setState({
      isCalander,
    });
  };

  handleOpen = async date => {
    let { isCalander, selectedDate } = this.state;
    isCalander = true;
    selectedDate = date;
    await this.setState({
      selectedDate,
    });
    await this.setState({
      isCalander,
    });
  };
  handleTreatmentHistory = () => {
    let { customerId } = this.state;
    if (customerId > 0) {
      this.setState(prevState => ({
        isTreatmentHistoryModal: !prevState.isTreatmentHistoryModal,
        customerNumber: this.state.customerId,
      }));
    } else {
      Toast({ type: "error", message: "Please select customer" });
    }
  };
  handleUpcomingAppointment = () => {
    let { customerId } = this.state;
    if (customerId > 0) {
      this.setState(prevState => ({
        isUpcomingAppointmentModal: !prevState.isUpcomingAppointmentModal,
        customerNumber: this.state.customerId,
      }));
    } else {
      Toast({ type: "error", message: "Please select customer" });
    }
  };

  handleSelectCustomer = async data => {
    await this.setState({
      customerId: data.id,
      custName: data.cust_name,
      custPhone: data.cust_phone1,
      isOpenModal: false,
      customerOption: [],
    });
  };

  handleSearch = async event => {
    await this.setState({ search: event.target.value });
    if (!this.debouncedFn) {
      this.debouncedFn = _.debounce(async () => {
        let { basicApptDetail } = this.props;
        this.search(basicApptDetail);
      }, 500);
    }
    this.debouncedFn();
  };

  search = basicApptDetail => {
    let { search } = this.state;
    this.props
      .getCommonApi(
        `custappt/?Outlet=${
          basicApptDetail.branchId ? basicApptDetail.branchId : ""
        }&search=${search}`
      )
      .then(key => {
        let { status, data } = key;
        if (status === 200) {
          this.setState({ customerOption: data });
        }
      });
  };
  handleDialog = () => {
    let { isOpenModal } = this.state;
    isOpenModal = !isOpenModal;
    this.setState({
      isOpenModal,
    });
  };
  render() {
    let {
      isCalander,
      selectedDate,
      isTreatmentHistoryModal,
      isUpcomingAppointmentModal,
      customerId,
      custName,
      custPhone,
      isOpenModal,
      customerOption,
      search,
    } = this.state;
    return (
      <>
       
        <div>
          <Scheduler handleOpen={this.handleOpen} />
        </div>
      </>
    );
  }
}

const mapStateToProps = state => ({
  basicApptDetail: state.appointment.basicApptDetail,
});

const mapDispatchToProps = dispatch => {
  return bindActionCreators(
    {
      getCustomer,
      getCommonApi,
    },
    dispatch
  );
};

export const NewListAppointment = connect(
  mapStateToProps,
  mapDispatchToProps
)(NewListAppointmentClass);
