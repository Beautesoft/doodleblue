import React, { Component } from 'react';
export class CustomerList extends Component {
    render() {
        return (
             <>
             </>
        );
    }
}