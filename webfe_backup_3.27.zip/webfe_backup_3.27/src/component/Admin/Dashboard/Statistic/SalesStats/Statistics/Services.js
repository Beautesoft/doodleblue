import React from 'react';
// import './style.scss'
export class Services extends React.Component {
    render() {
        return (
             <>
             </>
        );
    }
}