import React, { Component } from "react";
import "./devExpressScheduler/Styles.scss";
import Modal from "assets/images/modal-avatar.png";
import man from "assets/images/man.png";
import newUser from "assets/images/user-image.png";
import Scheduler, { Resource, View } from "devextreme-react/scheduler";
import "devextreme/dist/css/dx.common.css";
import "devextreme/dist/css/dx.light.css";
import ResourceCell from "./devExpressScheduler/ResourceCell";
import AppointmentCell from "./devExpressScheduler/AppointmentCell";
import { InputSearch } from "../InputSearch";
import _ from "lodash";
import { getCustomer, getCommonApi } from "redux/actions/common";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import { NormalButton,NormalInput,NormalModal } from "component/common";
import { StaffSorting } from "../../Admin/NewAppointment/NewListAppointment/modal/StaffSorting";
import { BlockPopup } from "../../Admin/NewAppointment/NewListAppointment/modal/BlockPopup";
import { PrintModal } from "../../Admin/NewAppointment/NewListAppointment/modal/PrintModal";
import { TreatmentHistory } from "../../Admin/NewAppointment/NewListAppointment/modal/TreatmentHistory";
import { UpcomingAppointment } from "../../Admin/NewAppointment/NewListAppointment/modal/UpcomingAppointment";
import { Toast } from "service/toast";
import html2canvas from "html2canvas";
import closeIcon from "assets/images/close.png";

const groups = ["id"];
const sleep = milliseconds => {
  return new Promise(resolve => setTimeout(resolve, milliseconds));
};
const views = [
  {
    type: "day",
    name: "day",
    groupOrientation: "Horizontally",
    intervalCount: 1,
  },
  {
    type: "week",
    name: "week",
    groupOrientation: "vertical",
    intervalCount: 1,
    maxAppointmentsPerCell: "unlimited",
  },
  {
    type: "month",
    name: "month",
    intervalCount: 1,
    groupOrientation: "Horizontally",
    maxAppointmentsPerCell: "unlimited",
  },
];

export class NewSchedulerModalClass extends Component {
  state = {
    selectedDate: new Date(),
    selectedView: "",
    DefaultDate: new Date(),
    DefaultView: "",
    searchtext: "",
    SelectedList: [],
    isOpenModal: false,
    isOpenBlockModal: false,
    appointmentId: 0,
    SchedulerHeight: 700,
    isOpenPrintModal: false,
    isOpenModalForCustomer: false,

    customerId: 0,
    custName: "",
    custPhone: "",
    customerOption: [],
    search: "",
    customerNumber: 0,

    isTreatmentHistoryModal: false,
    isUpcomingAppointmentModal: false,
  };

  onEmptyClick = e => {
    e.cancel = true;
    let date = new Date(e.cellData.startDate);
    if (e.cellData.groups) {
      this.props.onEmptyClick(date, e.cellData);
    } else {
      Toast({ type: "error", message: "Not available" });
    }
  };
  onAppointmentClick = async e => {
    e.cancel = true;
    await this.setState({ appointmentId: 0 });
    let date = new Date(e.appointmentData.startDate);
    if (e.appointmentData.status === "Block") {
      await this.setState({ appointmentId: e.appointmentData.appt_id });
      this.handleBlockDialog();
    } else {
      this.props.onEmptyClick(date, e.appointmentData);
    }
  };

  componentWillMount() {
    this.setState({
      DefaultDate: this.props.filterDate,
      DefaultView: this.props.filterType,
    });
  }

  handleViewChange = async e => {
    await this.setState({
      selectedView: e,
    });
    this.handleChange();
  };

  handleDateChange = async e => {
    await this.setState({
      selectedDate: e,
    });
    this.handleChange();
  };

  handleChange = () => {
    let {
      selectedDate,
      selectedView,
      DefaultDate,
      DefaultView,
      searchtext,
    } = this.state;
    let newDate = new Date();
    let newMode = "";
    let prevMode = DefaultView;
    let prevDate = DefaultDate;
    if (selectedView) {
      newMode = selectedView;
    } else {
      newMode = DefaultView;
    }
    if (selectedDate) {
      newDate = selectedDate;
    } else {
      newDate = selectedDate;
    }
    this.props.handleChangeFilter(
      prevMode,
      prevDate,
      newMode,
      newDate,
      searchtext
    );
  };

  onContentReady(e) {
    const currentHour = new Date().getHours() - 1;
    e.component.scrollToTime(currentHour, 30, new Date());
  }

  handleSearch = async event => {
    event.persist();
    await this.setState({ searchtext: event.target.value });
    if (!this.debouncedFn) {
      this.debouncedFn = _.debounce(() => {
        this.handleChange();
      }, 500);
    }
    this.debouncedFn();
  };

  handleDialog = () => {
    let { isOpenModal } = this.state;
    isOpenModal = !isOpenModal;
    this.setState({
      isOpenModal,
    });
  };
  handleBlockDialog = async () => {
    await this.setState(prevState => ({
      isOpenBlockModal: !prevState.isOpenBlockModal,
    }));
    await this.setState({ appointmentId: 0 });
  };
  handlePrintDialog = () => {
    let { isOpenPrintModal } = this.state;
    isOpenPrintModal = !isOpenPrintModal;
    this.setState({
      isOpenPrintModal,
    });
  };

  handleBack = () => {
    this.props.handleBack();
  };
  handleNext = () => {
    this.props.handleNext();
  };
  Snap = async () => {
    debugger;
    await this.setState({ SchedulerHeight: 3000 });
    await sleep(1000); //
    window.scrollTo(0, 0);
    let img = "";
    let base64URL = "";

    html2canvas(document.querySelector("#Scheduler"), {
      allowTaint: true,
      useCORS: true,
      logging: false,
      scale: 1,
      removeContainer: true,
    }).then(function (canvas) {
      img = canvas.toDataURL("image/png", 1);
      base64URL = img.replace("image/png", "image/octet-stream");
      var byteCharacters = atob(
        img.replace(/^data:image\/(png|jpeg|jpg);base64,/, "")
      );
      var byteNumbers = new Array(byteCharacters.length);
      for (var i = 0; i < byteCharacters.length; i++) {
        byteNumbers[i] = byteCharacters.charCodeAt(i);
      }
      var byteArray = new Uint8Array(byteNumbers);
      var file = new Blob([byteArray], { type: "image/png" + ";base64" });
      var fileURL = URL.createObjectURL(file);
      var a = document.createElement("a");
      a.setAttribute("download", "myImage.png");
      a.setAttribute("href", base64URL);
      a.click();
      window.open(fileURL);
    });
    window.scrollTo(0, document.documentElement.scrollHeight);
    await this.setState({ SchedulerHeight: 700 });
  };


  handleTreatmentHistory = () => {
    let { customerId } = this.state;
    if (customerId > 0) {
      this.setState(prevState => ({
        isTreatmentHistoryModal: !prevState.isTreatmentHistoryModal,
        customerNumber: this.state.customerId,
      }));
    } else {
      Toast({ type: "error", message: "Please select customer" });
    }
  };
  handleUpcomingAppointment = () => {
    let { customerId } = this.state;
    
    if (customerId > 0) {
      this.setState(prevState => ({
        isUpcomingAppointmentModal: !prevState.isUpcomingAppointmentModal,
        customerNumber: this.state.customerId,
      }));
    } else {
      Toast({ type: "error", message: "Please select customer" });
    }
  };
  handleSelectCustomer = async data => {
    await this.setState({
      customerId: data.id,
      custName: data.cust_name,
      custPhone: data.cust_phone1,
      isOpenModalForCustomer: false,
      customerOption: [],
    });
  };
  handleCustomerDialog = () => {
    let { isOpenModalForCustomer } = this.state;
    isOpenModalForCustomer = !isOpenModalForCustomer;
    this.setState({
      isOpenModalForCustomer,
    });
  };
  handleCustomerSearch = async event => {
    await this.setState({ search: event.target.value });
    if (!this.debouncedFn) {
      this.debouncedFn = _.debounce(async () => {
        let { basicApptDetail } = this.props;
        this.search(basicApptDetail);
      }, 500);
    }
    this.debouncedFn();
  };
  search = basicApptDetail => {
    let { search } = this.state;
    this.props
      .getCommonApi(
        `custappt/?Outlet=${
         ""
        }&search=${search}`
      ) 
      .then(key => {
        let { status, data } = key;
        if (status === 200) {
          this.setState({ customerOption: data });
        }
      });
  };
  render() {
    let {
      isOpenModal,
      isOpenBlockModal,
      appointmentId,
      SchedulerHeight,
      isOpenPrintModal,
      custName,
      isOpenModalForCustomer,
      customerOption,
      search,
      isTreatmentHistoryModal,
      isUpcomingAppointmentModal,
    } = this.state;
    let { filterDate } = this.props;

    return (
      <div style={{ width: "100%", height: "100%" }}>
        <React.Fragment>
          <StaffSorting
            isOpenModal={isOpenModal}
            handleDialog={this.handleDialog}
            handleChange={this.handleChange}
            filterDate={filterDate}
          />
          {isOpenBlockModal ? (
            <BlockPopup
              isOpenBlockModal={isOpenBlockModal}
              handleBlockDialog={this.handleBlockDialog}
              handleChange={this.handleChange}
              filterDate={filterDate}
              appointmentId={appointmentId}
            />
          ) : (
            ""
          )}
          {isOpenPrintModal ? (
            <PrintModal
              isOpenPrintModal={isOpenPrintModal}
              handlePrintDialog={this.handlePrintDialog}
            />
          ) : (
            ""
          )}

          <div className="d-flex justify-content-end p-1 m-1">
            {this.props.meta ? (
              <div className="col-2 text-right p-1">
                {this.props.meta.pagination &&
                this.props.meta.pagination.total_pages > 1 ? (
                  <div className="col-12">
                    <div>
                      {this.props.meta.pagination.total_pages <
                        this.props.meta.pagination.current_page ||
                      this.props.meta.pagination.current_page > 1 ||
                      this.props.meta.pagination.total_pages ==
                        this.props.meta.pagination.current_page ? (
                        <button
                          className="cursor-pointer dx-button-content disabled"
                          onClick={this.handleBack}
                        >
                          <svg
                            width="9"
                            height="15"
                            viewBox="0 0 6 10"
                            fill="none"
                            xmlns="http://www.w3.org/2000/svg"
                          >
                            <path
                              d="M5 0.5L1 5L5 9.5"
                              stroke="#888888"
                              stroke-linecap="round"
                              stroke-linejoin="round"
                            />
                          </svg>
                        </button>
                      ) : (
                        ""
                      )}
                      {/* <span className="dx-button-staff-content"> Staff </span> */}
                      {this.props.meta.pagination.total_pages >
                        this.props.meta.pagination.current_page &&
                      this.props.meta.pagination.total_pages !==
                        this.props.meta.pagination.current_page &&
                      this.props.meta.pagination.current_page > 0 ? (
                        <button
                          className="cursor-pointer dx-button-content"
                          onClick={this.handleNext}
                        >
                          <svg
                            width="9"
                            height="15"
                            viewBox="0 0 6 10"
                            fill="none"
                            xmlns="http://www.w3.org/2000/svg"
                          >
                            <path
                              d="M0.5 9.5L4.5 5L0.5 0.5"
                              stroke="#888888"
                              stroke-linecap="round"
                              stroke-linejoin="round"
                            />
                          </svg>
                        </button>
                      ) : (
                        ""
                      )}
                    </div>
                  </div>
                ) : (
                  ""
                )}
              </div>
            ) : (
              ""
            )}
            
            <div className="col-2">
              <NormalInput
                placeholder={"Select customer"}
                value={custName}
                name="customerName"
                onClick={() => this.setState({ isOpenModalForCustomer: true })}
                className={`search history-search-textbox px-2 p-0`}
              />
            </div>
            <div className="col-2">
              <div className="w-100 p-1">
                <NormalInput
                  placeholder="Select customer"
                  value={custName}
                  onClick={() => this.setState({ isOpenModalForCustomer: true })}
                  name="searchtext"
                />
              </div>
            </div>
            <div className="col-2">
              <NormalButton
                buttonClass={"treatment"}
                mainbg={true}
                className="col-12 fs-15 m-0 p-0"
                label="Upcoming Appointment"
                onClick={this.handleUpcomingAppointment}
              />
            </div>
            <div className="col-2">
              <NormalButton
                buttonClass={"treatment"}
                mainbg={true}
                className="col-12 fs-15 "
                label="Treatment History"
                onClick={this.handleTreatmentHistory}
              />
            </div>
      
            <div className="col-1">
              <NormalButton
                buttonClass={"p-0"}
                mainbg={true}
                className=" fs-15 confirm"
                label={`Screenshot`}
                outline={false}
                onClick={this.Snap}
              />
            </div>
            <div className="col-1">
              <NormalButton
                buttonClass={"p-0"}
                mainbg={true}
                className=" fs-15 confirm"
                label={`Print`}
                outline={false}
                onClick={() => {
                  this.setState({ isOpenPrintModal: true });
                }}
              />
            </div>
            <div className="col-1">
              <NormalButton
                buttonClass={"p-0"}
                mainbg={true}
                className=" fs-15 confirm"
                label={`Sort`}
                outline={false}
                onClick={() => {
                  this.setState({ isOpenModal: true });
                }}
              />
            </div>
            <div className="col-1">
              <NormalButton
                buttonClass={"p-0"}
                mainbg={true}
                className="fs-15 confirm"
                label={`Block`}
                outline={false}
                onClick={() => {
                  this.setState({ isOpenBlockModal: true });
                }}
              />
            </div>
            <div className="col-2">
              <div className="w-100 p-1">
                <InputSearch
                  placeholder="Search here.."
                  value={this.state.searchtext}
                  onChange={this.handleSearch}
                  name="searchtext"
                />
              </div>
            </div>
          </div>
          {isTreatmentHistoryModal ? (
          <TreatmentHistory
            isTreatmentHistoryModal={isTreatmentHistoryModal}
            handleTreatmentHistory={this.handleTreatmentHistory}
            customerNumber={this.state.customerNumber}
            custName={this.state.custName}
            custPhone={this.state.custPhone}
          />
        ) : (
          ""
        )}
        {isUpcomingAppointmentModal ? (
          <UpcomingAppointment
            isUpcomingAppointmentModal={isUpcomingAppointmentModal}
            handleUpcomingAppointment={this.handleUpcomingAppointment}
            customerNumber={this.state.customerNumber}
            custName={this.state.custName}
            custPhone={this.state.custPhone}
          />
        ) : (
          ""
        )}
          <NormalModal
          className={"multiple-appointment select-category"}
          style={{ minWidth: "800px" }}
          modal={isOpenModalForCustomer}
          handleModal={this.handleCustomerDialog}
        >
          <img
            onClick={this.handleCustomerDialog}
            className="close"
            src={closeIcon}
            alt=""
          />
          <div className="row">
            {" "}
            <h5 className="text-center">Select Customer</h5>
          </div>
          <div className="row mt-2 mb-5 mx-3">
            <div className="col-1 pl-0">Search</div>
            <div className="col-5">
              <input
                name="search"
                onChange={this.handleCustomerSearch}
                className="search m-0 p-0 px-3"
              />
            </div>
            <div className="col-3">
              <NormalButton
                buttonClass={"mx-2 p-0"}
                mainbg={true}
                className=" fs-15 confirm"
                label="Search"
                outline={false}
                onClick={() => this.search(search)}
              />
            </div>

            <div className="row mt-4 table-header w-100 m-0">
              <div className="col-2">Name</div>
              <div className="col-2">Phone</div>
              <div className="col-3">Cust Code</div>
              <div className="col-5">Email</div>
            </div>
            <div className="response-table w-100">
              {customerOption.length > 0 ? (
                customerOption.map((item, index) => {
                  return (
                    <div
                      className="row m-0 table-body w-100"
                      onClick={() => this.handleSelectCustomer(item)}
                      key={index}
                    >
                      <div className="col-2">{item.cust_name}</div>
                      <div className="col-2">{item.cust_phone1}</div>
                      <div className="col-3">{item.cust_code}</div>
                      <div className="col-5">{item.cust_email}</div>
                    </div>
                  );
                })
              ) : (
                <div className="text-center w-100">No Data are available</div>
              )}
            </div>
          </div>
        </NormalModal>
          <Scheduler
            id="Scheduler"
            height={SchedulerHeight}
            width={1500}
            dataSource={this.props.event}
            views={views}
            onContentReady={this.onContentReady}
            defaultCurrentView="day"
            groups={groups}
            startDayHour={8}
            endDayHour={21}
            firstDayOfWeek={0}
            showAllDayPanel={false}
            crossScrollingEnabled={true}
            cellDuration={15}
            resourceCellComponent={ResourceCell}
            editing={{
              allowUpdating: false,
              allowAdding: false,
              allowDeleting: false,
              allowDragging: false,
            }}
            onCellClick={e => this.onEmptyClick(e)}
            onAppointmentClick={e => this.onAppointmentClick(e)}
            //dateSerializationFormat="yyyy-MM-ddTHH:mm:ssZ"
            appointmentComponent={AppointmentCell}
            onCurrentViewChange={this.handleViewChange}
            onCurrentDateChange={this.handleDateChange}
          >
            <View type="day" label="day" />
            <View type="week" label="week" />
            <View type="month" label="month" />
            <Resource
              dataSource={this.props.staffList}
              fieldExpr="id"
              useColorAsDefault={true}
              allowMultiple={false}
            />
          </Scheduler>
        </React.Fragment>
      </div>
    );
  }
}

const mapDispatchToProps = dispatch => {
  return bindActionCreators(
    {
      getCommonApi,
    },
    dispatch
  );
};

export const NewSchedulerModal = connect(null, mapDispatchToProps)(NewSchedulerModalClass);


