export { NewListAppointment } from 'component/Admin/NewAppointment/NewListAppointment';
export { NewAppointmentDetail } from 'component/Admin/NewAppointment/NewAppointmentDetail';
export { NewCreateAppointment } from 'component/Admin/NewAppointment/NewCreateAppointment';
export { NewSelectTreatment } from 'component/Admin/NewAppointment/NewCreateAppointment/NewSelectTreatment';